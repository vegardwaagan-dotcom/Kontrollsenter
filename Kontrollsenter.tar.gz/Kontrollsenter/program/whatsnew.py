"""«Hva er nytt?» – innholdet vises i en dialog. Nyeste versjon øverst."""
import json
import os

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

import i18n  # noqa: E402

SEEN = os.path.expanduser("~/.config/systemmonitor/sett-versjon.json")

NEWS = [
    ("1.0.10", "Hjemmeport – NAS-en uten at noen PC står på", [
            "Ny «Hjemmeport» (NAS-disken): gjør en Raspberry Pi hjemme til porten inn til NAS-en – Kontrollsenter "
            "setter den opp over SSH (passordet én gang), installerer Tailscale, deler hjemmenettet og slår på "
            "automatiske sikkerhetsoppdateringer",
            "Mobilappen: knappen «NAS» på startskjermen åpner NAS-disken gjennom hjemmeporten – også når alle PC-ene er av",
            "Hjemmeporten svarer bare dine enheter (Tailscale og hjemmenettet) og krever en egen nøkkel som bare mobiler "
            "med full tilgang får",
        ]),
    ("1.0.9", "NAS-disken – også utenfor hjemmet", [
            "Ny side «NAS-disken» (System): bla i NAS-en som i en filbehandler – åpne, last ned, last opp (også ved å "
            "dra filer inn), lag mapper, gi nytt navn og slett",
            "Private mapper på NAS-en: logg inn én gang – passordet huskes i nøkkelringen, aldri i klartekst",
            "Mobilappen: kortet «NAS-disken» (PC-en › Nett og NAS) – bla, last ned til telefonen og last opp fra den",
            "Utenfor hjemmet: «Del hjemmenettet herfra» gjør at NAS-en kan nås gjennom Tailscale (kryptert, ingen porter "
            "åpnes). Mobilappen går via PC-en hjemme, så den virker borte så lenge den PC-en er på",
        ]),
    ("1.0.8", "«Oppdatering klar» når du starter", [
            "Alle appene ser etter ny versjon både på hjemmenettet (NAS) og på GitHub hver gang de starter",
            "PC (Linux og Windows): har du slått av automatisk oppdatering, kommer «Oppdatering klar» øverst i "
            "vinduet og som varsel – trykk «Oppdater nå». Med automatisk oppdatering på installeres den som før",
            "Android-appen: sjekker GitHub selv med en gang den åpnes (ikke bare via PC-ene), og viser "
            "«Oppdatering klar» med den nyeste versjonen før den kobler til PC-en (krever app 1.0.8)",
        ]),
    ("1.0.7", "Ny telefon? PC-en spør deg", [
            "Mobilappen: ny knapp «Spør PC-en om tilgang» når en telefon eller et nettbrett skal pares. Kontrollsenter "
            "på PC-en viser da et spørsmål med navnet og adressen til enheten – velg Godta, Godta begrenset eller "
            "Avvis. Telefonen og PC-en viser samme firesifrede kode, så du ser at det er din enhet",
            "Spørsmålet kommer både som eget vindu (også når Kontrollsenter ligger i statusfeltet) og som varsel med "
            "knapper (Linux) / varsel fra statusfeltet (Windows). Det utløper etter 2 minutter, en avvist enhet må "
            "vente 1 minutt før den kan spørre igjen, og nøkkelen gis bare til telefonen som spurte",
            "Den 6-sifrede koden virker fortsatt under «Har du en kode fra PC-en?»",
            "Gjelder Linux, Windows og Android-appen (paringsskjermen kommer fra PC-en – ingen ny app trengs)",
        ]),
    ("1.0.6", "Android-appen: ingen evig oppdatering", [
            "Mobilappen ba om oppdatering til 1.0.5 igjen og igjen: PC-en lovet app-versjonen til PC-programmet, "
            "men APK-en var fortsatt 1.0.4. Nå leser PC-en versjonen til selve APK-en, og en ny versjon blir ikke "
            "lagt ut før Android-appen og Windows-installasjonen er bygget for den",
            "Android-appen er nå 1.0.6 og har alt fra 1.0.5 (Sunshine «Start på nytt»)",
        ]),
    ("1.0.5", "Sunshine: «Start på nytt» på mobilen og ingen «Tillat»-spørsmål", [
            "Mobilappen › Spill › Spill på telefonen: ny knapp «↻ Start på nytt» for Sunshine (virker mot både "
            "Linux- og Windows-PC-er)",
            "Linux (KDE): Sunshine startet fra telefonen ble stående og vente på «Tillat fjernstyring?» på PC-skjermen. "
            "Kontrollsenter gir nå Sunshine fast tillatelse, så den starter uten at noen må trykke på PC-en "
            "(tas tilbake når Strømming slås av under Funksjoner)",
            "Sunshine som henger under oppstart (tjenesten kjører, men svarer ikke) startes nå på nytt av "
            "«Start», «Start på nytt» og «Hold Sunshine i gang» – før skjedde det ingenting",
            "Windows: Sunshine er en tjeneste der og spør aldri om lov – der var bare knappen ny",
        ]),
    ("1.0.4", "Gjennomgang: knapper som ikke virket", [
            "RGB (Linux og Windows): feilmeldingen ved hver oppstart og etter hvilemodus er borte («'RgbBackend' "
            "object has no attribute …»). OpenRGB-profilen lagres igjen, antall LED på vifteuttakene brukes, og på "
            "Linux lagres fargene på Logitech-mus og -tastatur i enheten",
            "Familie › Nettfilter (DNS) virker når IPv6 er slått av på nettverket (før: «ipv6.dns: this property is "
            "not allowed»)",
            "Mobilappen: alle «Kopier»-knappene virker (chat, AI, RustDesk-ID, ntfy-adressen, utklippstavlen og "
            "klipp-lenker) – før skjedde det ingenting",
            "Mobilappen: talemeldinger i chatten tas opp av appen selv (krever app-versjon 1.0.4 – oppdater appen). "
            "PC-en spiller nå av talemeldinger fra mobilen (de var stumme på Linux)",
            "Mobilappen: «Andreskjerm» holder skjermen våken mens du spiller",
            "Mobilappen: «Hva har jeg gått glipp av?» i chatten krasjet hver gang",
            "Vedlikehold: kort som «PC-legen» henger ikke lenger på «arbeider …» når noe feiler – du får beskjed",
            "Oversikt: minigrafene i flisene krasjet når en måling manglet (f.eks. ping uten svar)",
            "Wake-on-LAN kan slås på også når PC-en bruker Wi-Fi",
            "KDE-widgetene oppdateres automatisk etter en ny versjon – og Kalender-widgeten kommer med",
            "Hele programmet er gått gjennom på nytt med knapperoboten i en usynlig skjerm – nå også RGB-siden, "
            "feilmeldinger som vises på skjermen og knapper som ikke gjør noe – på PC (Klassisk og Lett) og mobil",
        ]),
    ("1.0.3", "Lokal AI fjernet", [
            "Den lokale AI-en (Ollama) er fjernet fra Kontrollsenter. AI-siden har Claude, Codex og Gemini – "
            "hadde du valgt lokal AI, brukes Claude nå",
        ]),
    ("1.0.2", "Nattlys-glideren riktig vei", [
            "Nattlys-glideren går nå riktig vei: mot høyre blir skjermen varmere og gulere, mot venstre mer nøytral",
        ]),
    ("1.0.1", "3D, Lett og innlogging uten passord", [
            "Nytt design «3D»: kort og knapper løfter seg ut av skjermen, knappene trykkes inn, kortene flyr inn og "
            "de viktigste knappene pulserer. I mobilappen vipper kortene etter fingeren (ekte 3D)",
            "Nytt design «Lett» (som LXQt): flatt og kompakt uten animasjoner, skygger eller glass – og tegning uten "
            "skjermkortet, så det bruker minst mulig minne",
            "Velg under Innstillinger › Utseende › Design – på PC-en, Windows og mobilen",
            "Logg inn uten passord etter en omstart fra Kontrollsenter (PC-en eller mobilen) – bare den ene gangen. "
            "Virker med Plasma Login, SDDM, GDM og LightDM. Under Innstillinger › Generelt › «Start på nytt og slå av»",
            "PC-appen har fått knappene «Start på nytt» og «Slå av»",
        ]),
    ("1.0.0", "Kontrollsenter 1.0", [
            "Hele programmet er gått gjennom: alle sidene, fanene, kategoriene og knappene er testet automatisk – på "
            "PC-en i både Klassisk og Nytt design (rundt 2900 handlinger) og i mobilappen (rundt 500)",
            "Rettet: «Spilloppdateringer om natten» mens Steam kjørte låste appen i en evig løkke som spiste opp minnet",
            "Rettet: dagboken – «Ny dagbok», å åpne en dagbok og Enter i kodefeltet krasjet",
            "Rettet: spillmodus med RGB-farge fra mobilen krasjet",
            "Rettet: Systemsjekk fra ikonet i statusfeltet, Oppstartstid uten data og «Spør AI om siste krasj»",
            "Rettet: den lokale AI-en fikk ikke PC-statusen, og Shelly-pluggen ga feil feilmelding",
            "Klipp: «Beste fra uka», «Skjermbilde» og «Start/stopp opptak» sier nå fra hvis noe ikke går",
            "Mobilappen: «Kopier» virker eller sier fra (RustDesk, chat og AI), lenker åpnes i ny fane i nettleseren, "
            "og «Hvem er på nå» ligger under Familie",
            "Nytt design tåler en ødelagt innstillingsfil for hjelpetekstene",
        ]),
    ("0.99.60", "Nattlys virker igjen på KDE", [
            "Rettet: nattlys-glideren og -bryteren under Skjerm gjorde ingenting på KDE Plasma 6.8 – innstillingen ble "
            "lagret, men KWin tok den ikke i bruk. Gjelder også nattlys fra mobilappen og i scener",
            "Drar du i nattlys-glideren mens nattlys er av, slås det på med den temperaturen",
        ]),
    ("0.99.59", "Tilpasset Hyprland og GNOME", [
            "Hyprland: mini-vinduet, widgetene, webkameraet og andre egne vinduer blir flytende i stedet for å "
            "legges inn i rutenettet. Mini-vinduet og widgetene kan ligge øverst, og widgetene husker plasseringen",
            "Hyprland: hurtigtastene (klipp, opptak, skjermbilde …) bindes direkte i Hyprland – nøyaktig tast, også i spill",
            "Hyprland: oppstart ved innlogging virker (Hyprland kjører ikke ~/.config/autostart selv)",
            "Hyprland: støtter både det nye Lua-oppsettet (hyprland.lua, Hyprland 0.55 og nyere) og hyprland.conf – "
            "Kontrollsenter skriver i samme språk som ditt oppsett, i en egen fil",
            "Hyprland: skjermprofiler med oppløsning, Hz, VRR og HDR, nattlys med hyprsunset, og valg av "
            "hovedskjermkort",
            "GNOME: hurtigtastene legges inn som egne tastatursnarveier – ingen spørsmål, nøyaktig tast",
            "GNOME: skjermprofiler (oppløsning og Hz) via GNOME sine egne skjerminnstillinger",
            "GNOME: statusfelt-ikonet – AppIndicator-utvidelsen slås på hvis den er installert",
            "Lysstyrke på eksterne skjermer med ddcutil (DDC/CI) når skrivebordet ikke styrer det selv",
            "Nytt kort under Innstillinger › Generelt › Skrivebord: hva som er tilpasset, og «Fjern det "
            "Kontrollsenter har lagt inn»",
        ]),
    ("0.99.58", "Nytt design – med bryter", [
            "Ny bryter under Innstillinger › Utseende › Design: velg «Klassisk» (slik som før) eller «Nytt design». "
            "Gjelder PC (Linux og Windows) og mobilappen",
            "Nytt design: menyen har 7 områder – Oversikt, Spill, Enheter, Hjemmet, Sosialt, AI og System – med "
            "faner øverst for sidene i hvert område",
            "«Finn alt» er et søkefelt øverst i menyen",
            "Kategoriene på lange sider er faner i stedet for ‹ rullehjul ›, og alle faner ser like ut",
            "Én ikonstil: emoji er fjernet fra overskrifter, kategorier og faner (beholdt i Familie og Chat)",
            "Hvert kort har høyst én fremhevet knapp, og kort for feilsøking er lukket til du trykker «Vis»",
            "Hjelpeteksten øverst på en side vises bare første gang",
            "8 utvalgte temaer først – resten under «Flere temaer». Glass og overganger slås av når du bytter "
            "(kan slås på igjen), og kommer tilbake hvis du går tilbake til Klassisk",
            "Felles designverdier for hjørner, avstander, tekst og statusfarger – samme på PC og mobil. Tall har fast "
            "bredde, så de ikke hopper",
            "Windows: Segoe UI Variable, mindre hjørner og vindusknappene på Windows-måten",
            "Mobilappen: fanene nederst har samme navn og rekkefølge som områdene på PC-en. Valget deles med "
            "startskjermen og alle PC-ene (krever ny app-versjon – eldre app husker valget per PC)",
            "Rettet: lyse temaer (Sand, Mint, Papir, Latte, Krom) ble vist som mørke i mobilappen",
        ]),
    ("0.99.57", "Finn alt", [
            "Ny fane «Finn alt» øverst i menyen: alle sidene, kategoriene og innstillingene på ett sted – trykk for "
            "å gå rett dit",
            "Søk i alt fra samme fane (eller Ctrl+K). Enter går til første treff",
            "Søket finner nå også innstillinger i kategorier som ikke vises, og bytter til riktig kategori",
            "Mobilappen: 🔎 øverst åpner «Finn alt» med oversikt over alle fanene og kortene, og søk",
        ]),
    ("0.99.56", "Liste over spill med DLSS 5", [
            "Ny liste over alle spill med DLSS 5, rett fra NVIDIA sin offisielle oversikt – oppdateres av seg selv",
            "Varsel når et nytt spill får DLSS 5 (og om du har det installert)",
            "Bibliotek viser hva NVIDIA oppgir for hvert spill (DLSS 5, 6× bildegenerering, path tracing …)",
            "Mobilappen: eget panel «Spill med DLSS 5»",
            "«Nyeste DLSS automatisk» får nå også NVIDIA sin egen tillatelse, så den faktisk virker",
        ]),
    ("0.99.55", "DLSS 5, trygg overklokking og spillprofiler", [
            "DLSS 5 (Neural Rendering): nyeste modell i spill som har DLSS 5 innebygd (RTX 50)",
            "Bildegenerering: velg modell – nyeste eller den nye Ytelsesmodusen (Preset C, opptil 35 % raskere)",
            "DLSS, bildegenerering og Reflex per spill (Spill → Bibliotek, åpne spillet)",
            "Bibliotek viser hvilken DLSS-versjon hvert spill har med seg",
            "«DLSS i bruk nå» viser versjonen spillet som kjører faktisk bruker",
            "Trygg overklokking: går opp litt om gangen, sjekker for regnefeil og ender et trygt stykke under "
            "grensen. Krasjer PC-en, husker den steget",
            "Ferdige profiler: Effektiv (samme FPS, mindre strøm), Stille, Mild, Skannet maks og Standard",
            "Spillprofiler kan velge GPU-profil per spill – settes når spillet starter og tilbake når det lukkes",
            "Windows: DLSS-valgene skrives rett i NVIDIA-driveren, som DLSS-overstyringen i NVIDIA-appen",
            "Én felles «Gi tilgang»: ett passord for skjermkort, strøm, vifter og MSI (også i Systemsjekk)",
            "Mobilappen: DLSS 5, profiler og trygg overklokking i NVIDIA-panelet",
        ]),
    ("0.99.54", "DLSS, Reflex og G-SYNC", [
            "Velg DLSS-versjon for alle spill: nyeste, DLSS 4.5 (M/L), DLSS 4 (K/J), DLSS 3 og DLSS 2",
            "DLSS-kvalitet: DLAA, Kvalitet, Balansert, Ytelse eller Ultra ytelse",
            "Bildegenerering: nyeste modell, 2×–6× multi frame eller dynamisk etter skjermens Hz",
            "Ray Reconstruction med nyeste modell, NVIDIA Reflex med ekstra hjelp via Vulkan, og G-SYNC/VRR i spill",
            "Alt finnes også i NVIDIA-panelet i mobilappen",
        ]),
    ("0.99.53", "Flere NVIDIA-funksjoner", [
            "Overklokking: klokke-offset for GPU og minne – virker også på Wayland",
            "Vifter: automatisk, fast fart eller egen viftekurve etter temperaturen",
            "«Hva begrenser ytelsen» viser om strømgrensen, varme eller noe annet bremser kortet",
            "Spillvalg: NVIDIA Smooth Motion, nyeste DLSS-modell (DLSS 4), DLSS-info i spillet og trådede "
            "OpenGL-optimaliseringer",
            "Mobilappen: nytt NVIDIA-panel med vifter og ferdige overklokkingsvalg",
            "Trykk «Gi tilgang» én gang til under GPU-innstillinger for de nye funksjonene",
        ]),
    ("0.99.52", "Virker på flere Linux-varianter", [
            "Systemsjekk finner og installerer bibliotekene funksjonene trenger (grafer, lyd, NAS, dagbok, kontroller) "
            "med riktige pakkenavn for Arch, Fedora, Debian/Ubuntu, openSUSE, Void og Solus – ett trykk",
            "Brannmur: Systemsjekk ser om firewalld eller ufw stenger ute mobilappen, TV-en og chatten, og åpner port "
            "27100 og 27160–27189 bare for hjemmenettet. VR-oppsettet bruker det samme og virker nå også med ufw",
            "Oppløsning og Hz virker også på X11 (xrandr) og Sway/Hyprland (wlr-randr). På GNOME åpner knappen "
            "skjerminnstillingene",
            "Nattlys styres også på GNOME, og lysstyrken på bærbare virker på alle skrivebord",
            "Systemoppdateringer og programinstallasjon også på Void og Solus",
            "Installasjonsskriptet legger inn tilleggene med en gang, og støtter Void og Solus",
            "Uten statusfelt (GNOME uten AppIndicator) forklarer Kontrollsenter hvordan du åpner det igjen",
        ]),
    ("0.99.51", "Arch, CachyOS, Debian og openSUSE", [
            "Installere programmer virker nå på Arch/CachyOS og andre Linux-varianter uten Flatpak: Flatpak "
            "installeres først (du skriver passordet), så programmet fra Flathub",
            "Systempakker (FFmpeg, WireGuard, Tailscale) installeres med pacman, dnf, apt eller zypper – og hjelpeteksten "
            "viser riktig kommando for din Linux (ikke «sudo dnf» på Arch)",
            "Systemoppdateringer – kjerne, drivere, Mesa, NVIDIA – virker nå også på Arch/CachyOS (pacman, nøkkelringen "
            "først), Debian/Ubuntu (apt) og openSUSE (zypper). Før sto det «Ikke støttet»",
            "Rettet: Spill-siden krasjet på PC-er uten Steam",
        ]),
    ("0.99.50", "Oppdaterer seg selv ved oppstart", [
            "Ny bryter i Innstillinger › Oppdatering: «Oppdater automatisk når Kontrollsenter starter». Når PC-en har "
            "vært av eller du har lukket programmet helt, ser det etter ny versjon (hjemmenettet først, så GitHub), "
            "installerer den og starter på nytt av seg selv",
            "Den venter hvis noen spiller, og sjekker ikke igjen rett etter sin egen omstart",
            "Også i mobilappen: Innstillinger › PC-en og appen › PC-en",
        ]),
    ("0.99.49", "Endre driveradressene selv", [
            "Vedlikehold › Drivere: ⚙ ved «NVIDIA-drivere» og «AMD-drivere» – lim inn ny adresse hvis siden flytter, "
            "eller trykk «Standard» for å gå tilbake",
        ]),
    ("0.99.48", "Riktig NVIDIA-lenke", [
            "Vedlikehold › Drivere: «NVIDIA-drivere» åpner nå nvidia.com/en-eu/drivers (den gamle norske adressen "
            "ga «Not Found»)",
        ]),
    ("0.99.47", "«Hva er nytt?» og «Om» virker igjen", [
            "☰-menyen: «Hva er nytt?» og «Om Kontrollsenter» åpnet seg ikke – nå virker de igjen",
            "Selvtesten åpner nå menyvalgene før hver ny versjon, så en slik feil ikke slipper ut igjen",
        ]),
    ("0.99.46", "Riktig anbefaling for «Eldre PC»", [
            "«Eldre PC – lett grafikk» anbefales bare når PC-en faktisk trenger det: 4 kjerner eller færre, under 8 GB "
            "minne, lav klokkefrekvens eller lav score i ytelsestesten – og det står hvorfor",
            "Før ble alle PC-er med 8 kjerner eller færre regnet som gamle – også raske X3D-prosessorer med bare én "
            "CCD slått på",
        ]),
    ("0.99.45", "Gjennomgang: testet, ryddet og enklere tekst", [
            "Alle funksjonene er testet: 79 funksjonstester, 75 app-endepunkter, alle sider og faner på PC-en og alle "
            "faner og kategorier i mobilappen på telefonbredde",
            "Dagboken i appen svarer med en gang – NAS-en hentes i bakgrunnen (før kunne den henge)",
            "Ubrukt kode fjernet, og enklere, kortere forklaringer på flere kort (Diskhelse, Kontrollere, Spill på "
            "telefonen, Automatisk opprydding, Pushvarsler …)",
            "Rettet gamle henvisninger til fanene i appen (Familie ligger nå under Hjemmet)",
        ]),
    ("0.99.44", "Raskere, lettere og med overganger", [
            "Rettet minnelekkasje: gamle kopier av webkamera-overlayet ble liggende etter hver oppdatering "
            "(8 kopier = 432 MB). Nå ryddes de og avsluttede hjelpeprosesser bort ved oppstart",
            "Sidene du bruker mest bygges på forhånd mens du ikke gjør noe – de åpnes med en gang",
            "Spill, AI og Innstillinger åpnes 30–45 % raskere (WoW-søket og klipp-sjekken huskes i stedet for å "
            "gjøres på nytt hver gang)",
            "Vinduet oppdateres annethvert sekund når du ikke har rørt mus eller tastatur på 20 sekunder – sparer "
            "CPU, og går tilbake til hvert sekund med en gang du er der",
            "Nytt valg: Utseende › Effekter og overganger › Overganger: Glid, Fade eller Av – også i mobilappen",
            "Diskvakt: skriver Kontrollsenter uvanlig mye til disken, logges det hvilke programmer som kjører",
        ]),
    ("0.99.43", "Skrolling endrer ikke lenger glidere", [
            "PC-en (Linux og Windows): musehjulet over en glider (volum, lysstyrke, vifter …) eller et tallfelt ruller "
            "siden i stedet for å endre verdien. Gliderne justeres ved å dra, klikke eller med piltastene",
            "Mobilappen: fingeren må dra sidelengs før en glider endres – drar du opp eller ned, skroller siden og "
            "verdien blir som den var, også om du kommer borti glideren",
            "TV-en: opp/ned på fjernkontrollen over en glider går videre til neste knapp i stedet for å endre verdien",
        ]),
    ("0.99.42", "7.1 i hodesettet med én knapp", [
            "Lyd › «🎧 7.1 i hodesettet»: én knapp som gir virtuell 7.1 i hodesettet – PRO X 2 og andre hodesett "
            "finnes automatisk. Spill og filmer ser en 7.1-utgang, og du hører lyden rundt deg",
            "Når 7.1 er på, velger høyttalertesten og lydsirkelen 7.1 av seg selv – dra lyden rundt og hør",
            "Mobilappen og TV-en: bryteren «🎧 7.1 i hodesettet» øverst i Lyd-kortet",
            "Windows: knappen åpner «Romlyd» (Windows Sonic for hodetelefoner)",
        ]),
    ("0.99.41", "Jevnere lydsirkel", [
            "Lydsirkelen: når du drar knappen, flyttes ikke lenger hele vinduet",
            "Lyden hakker ikke lenger mens du drar: støyen lages nå av lydsystemet selv, og Kontrollsenter flytter "
            "bare miksen mellom høyttalerne – 100 ganger i sekundet, med myke overganger",
            "Sirkelen tegnes maks én gang per skjermbilde mens du drar",
        ]),
    ("0.99.40", "Drivere", [
            "Ny fane Vedlikehold › Drivere: «🌐 Åpne driversiden» går rett til ASUS-siden for ROG STRIX X870E-E "
            "GAMING WIFI (⚙ for å endre adressen), med hovedkortet og BIOS-versjonen du har nå",
            "Skjermkortdriveren (NVIDIA 620.70.06) med lenker til NVIDIA og AMD, og «Kjør driversjekk» for kjerne, "
            "Mesa og fastvare (Linux) / Windows Update › Valgfrie oppdateringer (Windows)",
            "Mobilappen: 🧩 Drivere under PC-en › PC-verktøy",
            "Rettet: lenker til andre nettsider (driversiden, pakkesporing …) åpnes nå i telefonens nettleser – før "
            "skjedde det ingenting",
        ]),
    ("0.99.39", "Lydsirkel og stopp-knapper", [
            "🎯 Lydsirkel i høyttalertesten: dra den runde knappen rundt sirkelen, så flytter lyden seg dit i rommet – "
            "glatt mellom høyttalerne. «Snurr rundt» tar én runde på 5 sekunder. Høyttalerne i oppsettet vises rundt "
            "sirkelen",
            "Også i mobilappen (dra med fingeren) og på TV-en (piltastene drar knappen, OK starter/stopper)",
            "■ Stopp på «Test lyd» (trykk igjen), i mikrofontesten og i lydsirkelen – og høyttalertestens Stopp stopper "
            "alt. Lyden stopper også når du går fra Lyd-siden",
        ]),
    ("0.99.38", "Temaer fra år 3000", [
            "Tre nye temaer under Innstillinger › Utseende: «År 3000 – Holografisk» (mørkt glass med holografiske "
            "kanter i cyan, fiolett og rosa), «År 3000 – Krom» (perlegrått og sølv med is-blå detaljer) og "
            "«År 3000 – Kosmos» (stjernehimmel, stjernetåke og nordlysgrønt)",
            "Tynnere, luftigere skrift på store tall og overskrifter, glødende knapper og målere med fargeoverganger",
            "Med Effekter = Full skifter de holografiske kantene sakte farge og bakgrunnen driver – står stille når "
            "vinduet ikke er i fokus, i spill, med «Minimal prosessbruk» og på eldre PC-er",
            "Samme temaer i mobilappen og på TV-en",
        ]),
    ("0.99.37", "TV-dashbord, Andreskjerm, talekommandoer og offline", [
            "📺 TV-dashbord: klokke, vær, strømpris, dagens plan og alle PC-ene i stort – kommer av seg selv på TV-en "
            "etter 5 minutter uten bruk, eller fra PC-en › Fjernstyring",
            "🎮 Andreskjerm: telefonen ved siden av tastaturet mens du spiller – store tall for FPS, CPU, GPU og "
            "strøm, og knapper for Discord-mikrofon, lyd, klipp og overlay. Skjermen holdes våken",
            "🎙️ Talekommandoer: mikrofon-/søkeknappen på TV-fjernkontrollen (eller knappen i appen) – «spillmodus på», "
            "«demp», «volum 30», «stille i to timer», «middag», «beskjed kom ned», «lagre klipp» eller navnet på en scene",
            "⌚ Klokka: varslene kommer på smartklokka via telefonen – «Send testvarsel» under Innstillinger › Varsler",
            "📴 Offline: når PC-en ikke svarer, viser appen det den sist visste, med en linje som sier fra",
        ]),
    ("0.99.36", "Styreflate, AI-scener og PC-legen", [
            "🖱️ Styreflate (PC-en › Fjernstyring): telefonen eller TV-fjernkontrollen som mus og tastatur for PC-en – "
            "dra, trykk, to fingre for høyreklikk/rulling, piltaster og OK på TV-en, og skriv tekst",
            "🤖 AI-en kan lage og kjøre scener: «Lag en filmkveld-scene med dempet lys» (du godtar først)",
            "✨ «Hva har jeg gått glipp av?» i chatten (⋯-menyen, også på mobilen): AI-en oppsummerer",
            "🎯 «Spør om spillet jeg spiller» på AI-siden: spillet og maskinvaren fylles inn, du skriver spørsmålet",
            "🤖 AI-hjelp etter krasj (Vedlikehold › Feilsøking) – og varsel som tilbyr det når PC-en har krasjet",
            "🩺 PC-legen: hver søndag lager AI-en ukas helserapport med de 3 viktigste tingene å fikse",
        ]),
    ("0.99.35", "Middagsplan, pakker, beskjed til alle og søvnrapport", [
            "🍽️ Middagsplan (Familie › Hverdagen): ukas middager med ingredienser som huskes – «Ukas ingredienser "
            "til handlelista» og 🎲 forslag. Vises i kalenderen hos alle",
            "📦 Pakker: lim inn sporingsnummeret – Posten/Bring, PostNord, UPS og DHL kjennes igjen, «Spor →» åpner "
            "riktig side, og leveringsdagen havner i kalenderen",
            "📢 Beskjed til alle: vises på alle PC-ene (over spillet), telefonene og i stort på TV-en",
            "😴 Søvnrapport: når PC-ene i huset sist var på hver kveld mot leggetiden – og «Slå av TV-en ved leggetid» "
            "(Samsung-TV-en, med 10 min varsel)",
            "🖼️ Minnevegg: bildene fra chatten som lysbildeshow i fullskjerm – på PC-en eller TV-en",
            "Spilloppdateringer om natten følger nå de billigste strømtimene",
            "Mobilappen og TV-en: Hjemmet › 🍽️ Hverdagen og 📢 Beskjed og minnevegg. Kategorilinja får ikke lenger "
            "plass-problemer med lange navn",
        ]),
    ("0.99.34", "PC-ens helse, stresstest og strømbudsjett", [
            "❤️ PC-ens helse (Vedlikehold › System og på Oversikt): ett tall 0–100 ut fra temperaturer, diskene, "
            "ledig plass, krasj, oppdateringer, støv og sikkerhetskopi – med «Fiks →» på hvert punkt",
            "🔥 Stresstest: prosessor og minne på full guffe i 2–15 min med temperaturgraf – regnefeil avslører en "
            "ustabil PC, og struping vises",
            "📊 Sammenlign ytelsestesten med de andre PC-ene i huset",
            "💡 Strømbudsjett: kr per måned, varsel ved 80 % og når det ser ut til å gå over",
            "Diskhelse viser forventet levetid igjen for SSD-en, og BIOS-alderen vises med lenke til produsenten",
            "🤫 «Stille nå» i 1, 2 eller 4 timer (Innstillinger › Automatikk) – rolige vifter og lavere effekt",
            "Mobilappen og TV-en: helsepoengene i Helse-flisen på Hjem, og PC-en › 🤫 Stille, strøm og stresstest",
        ]),
    ("0.99.33", "Spillkveld, spillår og nettet i spillet", [
            "🏆 LAN-turnering (Spill › Spillene): lag, poengtavle med +1, «Spillmodus på alle» PC-ene og vinner i "
            "chatten – deles med alle PC-er og mobiler hjemme",
            "📶 Nettet i spillet: ping og pakketap til selve spillserveren (også WoW og andre spill utenfor Steam), "
            "internett og ruteren – og om laggen kommer fra deg eller serveren",
            "🎁 Ditt spillår (Statistikk): timer, favorittspill, lengste økt, beste dag, klipp og prestasjoner – del "
            "i chatten",
            "⚖️ Før og etter: merk en endring (driver, Proton …) og se om FPS ble bedre per spill",
            "💾 Plass per spill (Bibliotek): store spill du ikke har spilt på et halvt år, med «Avinstaller», og "
            "spilloppdateringer bare om natten (02–06)",
            "Kontrollere: «Test kontrolleren →» åpner den nye, fullere testen under Utstyr › Tester (den gamle er fjernet)",
            "Alt også i mobilappen og på TV-en: Spill › 🏆 Spillkveld og nett og 🎁 Spillår og plass",
        ]),
    ("0.99.32", "Lydfiltre, nivåkalibrering og skjermprofil per spill", [
            "Lyd › Lydfiltre: virtuell 7.1 i et vanlig stereohodesett, equalizer (10 bånd, med «Spill», «Film», "
            "«Musikk», «Tale» og «Ekstra bass») og støyfilter på mikrofonen – alt med PipeWire, ingenting installeres",
            "«🎯 Kalibrer nivåer» i høyttalertesten: mikrofonen måler hver høyttaler der du sitter, og volumet justeres "
            "per kanal så alle blir like høye",
            "Skjermprofil per spill (Spill › Per spill): f.eks. HDR på og høyeste Hz når spillet starter, tilbake "
            "etterpå – ved siden av lydprofil per spill",
            "Batteriet i hodesettet, musa, tastaturet og kontrolleren vises på Oversikt (⚠ under 15 %)",
            "Mobilappen og TV-en: lydfiltrene, equalizer og kalibrering under PC-en › Lyd og skjerm",
            "Windows: Lydfiltre-kortet åpner Windows' egne (Windows Sonic, lydforbedringer), og kalibreringen "
            "justerer volumet per kanal",
        ]),
    ("0.99.31", "Oppløsning og Hz, og tester for skjerm, mikrofon, mus og kontroller", [
            "GPU-innstillinger › Skjerm og lys › «Oppløsning og Hz»: velg oppløsning og oppdateringsfrekvens for hver "
            "skjerm, og HDR og VRR. Går tilbake av seg selv etter 15 sekunder hvis du ikke trykker «Behold»",
            "Ny side «Tester» under Utstyr: skjermtest i fullskjerm (døde piksler, fargebånd, svart- og hvitnivå, "
            "skarphet, bevegelse og hvor mange Hz skjermen faktisk viser)",
            "Mus og tastatur: klikk, rullehjul, polling rate, dobbeltklikk-feil, hvor mange taster samtidig",
            "Kontroller: alle knapper, stikker og avtrekkere live, «Mål drift» med anbefalt dødsone, og vibrasjon",
            "Lyd › «Mikrofontest»: ta opp 5 sekunder, hør det igjen og få nivå, bakgrunnsstøy og råd",
            "Mobilappen og TV-en: oppløsning og Hz på PC-en med «Behold/Angre», og PC-en › 🧪 Tester: skjermtest og "
            "kontrollertest for telefonen/TV-en selv, og start skjermtesten på PC-en",
        ]),
    ("0.99.30", "Test hodesett og høyttalere", [
            "Lyd › «Test hodesett og høyttalere»: alle oppsett fra mono, stereo og 2.1 til 5.1, 7.1, 9.1 og Atmos "
            "(5.1.2, 5.1.4, 7.1.2) – 18 i alt",
            "Høyttalerne står der de står i rommet – trykk på en, så sier den navnet sitt og spiller støy, bare fra "
            "den høyttaleren",
            "«Én og én» går rundt hele rommet, «Alle samtidig», «Bass-sveip» (20–120 Hz i subwooferen) og «Motfase» "
            "som avslører en høyttaler som er koblet feil",
            "Velg utgang (f.eks. 7.1-lydkortet eller hodesettet) – oppsettet foreslås ut fra hvor mange kanaler den har",
            "Også i mobilappen og på TV-en (PC-en › Lyd og skjerm) – og «Test hodesettet på telefonen» for venstre/høyre "
            "på telefonens eget hodesett",
        ]),
    ("0.99.29", "Ryddigere app og kalender som lagrer", [
            "Mobilappen har nye faner: «PC-en» (styring, verktøy, historikk, nett og fjernstyring), «Spill» (bare "
            "spill, klipp, prestasjoner og VR) og «Hjemmet» (kalender og dagbok, familie, scener og smarthus, venner)",
            "Kalenderen ligger nå under Hjemmet i appen – ikke under Spill",
            "Ny hendelse i kalenderen på PC-en: Enter lagrer, du får «✓ Lagret», og kalenderen hopper til dagen "
            "hendelsen ble lagt på",
            "Vedlikehold: «Utstyr» heter nå «Batteri og skjerm» og «Trygghet og nett» heter «Sikkerhet», så de ikke "
            "forveksles med Utstyr-siden og Nettverk",
            "Lyden følger hodesettet, vent mens noen spiller og ukens beste øyeblikk er flyttet til Innstillinger › "
            "Automatikk, der de andre automatikkene ligger",
            "Har du ikke startet på nytt etter en oppdatering, bruker du fortsatt den gamle versjonen – trykk "
            "«Start på nytt» i den blå linjen øverst",
        ]),
    ("0.99.28", "Opprydding, rettelser og Google TV", [
        ("Google TV", [
            "Android-appen kan nå installeres på Google TV / Android TV og vises i TV-ens appliste med eget banner",
            "Styres med fjernkontrollen: tydelig fokusramme, piltaster og OK virker på alt, større tekst",
        ]),
        ("Rettet", [
            "Oppstartsveiviseren: alle 23 funksjonene vises (de nederste ble kuttet av før) – med oppdaterte beskrivelser",
            "Oversikt, Kalender og AI kunne tvinge vinduet bredere enn en 1280-skjerm – nå brytes knappene til ny linje",
            "Mobilappen: chat-toppen (rom + knapper) var for bred på smale telefoner",
        ]),
        ("Ryddet", [
            "Gammel kode som ikke var i bruk er fjernet (ca. 200 linjer)",
            "«Tale til tekst» avinstalleres når AI slås av under Funksjoner (den installeres av Kontrollsenter)",
            "Dagboken: «Slett dagboken» (krever koden)",
        ]),
        ("GitHub", [
            "Lenke til GitHub-siden under Innstillinger › Oppdatering, i mobilappen (Appen) og på appens startside",
        ]),
    ]),
    ("0.99.27", "Kalenderen: velg hva som vises", [
        ("Kalender", [
            "«👁 Vis» øverst: velg hva som vises hver dag – egne hendelser, bursdager, ukeplan, merkedager, flaggdager, "
            "skoleferier, måne, vær, spill, PC-en, strømpris, hvem var hjemme og Google/Outlook. Røde dager vises alltid",
            "Kalenderen fyller hele ruten sin, med titlene på hendelsene rett i dagene",
            "Bare kolonnen til høyre ruller – kalenderen står fast",
            "«Kommer snart» viser bare det som skjer (ikke vær og strømpris)",
            "Mobilen: «👁 Vis i kalenderen» med de samme valgene",
        ]),
    ]),
    ("0.99.26", "Hendelser lagres – og tydelig ukenummer", [
        ("Kalender", [
            "Rettet: hendelser ble ikke lagret når klokkeslett eller dato var skrevet på en annen måte (f.eks. «14» "
            "eller «24.11») – og feilmeldingen kom ikke fram",
            "Dato velges i en kalender og klokkeslett med timer og minutter (eller «Hele dagen»)",
            "Tydelig ukenummer: «Uke 48 · partallsuke» over måneden, ukenumrene i fargede felt (partall uthevet), "
            "og partall/oddetall i dagen og ukevisningen – også på mobilen",
            "Flere hendelser rett etter hverandre lagres sikkert (nyeste versjon vinner mot NAS-en)",
        ]),
    ]),
    ("0.99.25", "Kalenderen kobles til alt", [
        ("Spill og venner", [
            "Spilletid per dag (rødt ⚠️ når grensen ble passert), WoW-reset hver onsdag, gratis Epic-spill og "
            "Steam-salgene (ca.-datoer)",
            "Spillkveld: «💬 Inviter i chatten» med svarknapper (Kommer / Kanskje / Nei)",
            "«Når vennene pleier å spille» – Kontrollsenter noterer når vennene er på",
        ]),
        ("PC-en", [
            "Per dag: maks CPU/GPU-temperatur og kWh, PC-dagbok (ny versjon, temperatur, omstart …) og "
            "planlagte oppgaver (opprydding, automatiske AI-oppgaver, ukens video)",
            "AI-en kan lese og legge inn i kalenderen: «Legg inn tannlege tirsdag kl. 14» (med Godta/Avbryt) og "
            "«Når er neste langhelg?»",
        ]),
        ("Hjemmet og familien", [
            "Vær for de neste 10 dagene og strømprisen i dag rett i kalenderen",
            "Middag: «🛒» legger ingrediensene i handlelista · klipp og skjermbilder på dagen de ble tatt",
            "Hvem som var hjemme (PC-ene som var på) · røde dager og skoleferier gir helgegrensen for spilletid",
            "Google/Outlook-kalenderen fra Oversikt-flisen vises i kalenderen",
        ]),
        ("Widgets", [
            "Ny kalender-widget: på KDE-skrivebordet, Windows-skrivebordet og hjemmeskjermen på Android",
        ]),
    ]),
    ("0.99.24", "Kalender med hendelser – og dagbok", [
        ("Kalender", [
            "Egne hendelser: tid, farge, påminnelse og gjentakelse (hver uke, måned, år …) – delt med hele huset på NAS-en",
            "Typer: hendelse, søppel (varsel kvelden før), middag, rutine (f.eks. «støvsug PC-en hver 3. måned»), "
            "garanti, abonnement, spillkveld, gjøremål med avkrysning og Smart Hjem-scene som kjøres på tiden",
            "Bursdager og ukeplanen fra Familie, flaggdager 🇳🇴, skoleferier (still inn ukene under ⚙️), "
            "fullmåne/nymåne og sol opp/ned",
            "Visning: Måned, Uke og År – pluss søk, ferieplanlegger («ta 4 dager fri i påsken = 11 dager») og "
            "antall arbeidsdager",
            "Skriv ut hele året som PDF 🖨️",
            "Oversikt viser dagens hendelser og nedtelling («30 dager til 🎄 jul»)",
        ]),
        ("Dagbok", [
            "Hver i familien får sin egen dagbok med egen kode på 4–6 sifre (Kalender › Dagbok)",
            "Kryptert (AES-256) – ingen kan lese den uten koden, heller ikke fra NAS-en. Glemt kode kan ikke hentes tilbake",
            "Fem feil koder låser dagboken en stund · låses når du går fra siden eller etter 5 minutter",
            "Humør-emoji per innlegg, bytt kode, slett innlegg",
        ]),
        ("Mobilappen", [
            "Spill-fanen › 📅 Kalender og dagbok: hendelsene fra huset, legg til/endre, søk, ferieplanlegger",
            "Dagboken med tallpanel for koden",
        ]),
    ]),
    ("0.99.23", "Kalender med røde dager", [
        ("Ny: Hjemmet › Kalender", [
            "Kalender med alle norske røde dager markert i rødt (nyttår, påske, 1. og 17. mai, Kristi himmelfart, "
            "pinse og jul) – pluss søndager",
            "Bla så langt fram i tid du vil: måned for måned, velg år (helt til 2300) og «I dag»",
            "Ukenummer, merkedager med prikk (morsdag, farsdag, julaften, sankthans …) og hvor mange dager det er igjen",
            "«Neste røde dager» og alle røde dager i året, med 🏖️ for langhelger",
            "Også i mobilappen (Spill-fanen › 📅 Kalender) – virker uten kontakt med PC-en, sveip for å bla",
        ]),
    ]),
    ("0.99.22", "Ryddet bort det som lå dobbelt", [
        ("Ryddet", [
            "«Gå tilbake til forrige systemversjon» ligger bare under Vedlikehold › Gjenoppretting (ikke også i Utstyr)",
            "Kontrollere ligger bare under Spill › Kontrollere – nå med batteriet i selve kontrollerne "
            "(mus og hodesett står under Batterier på Oversikt)",
            "Wi-Fi-signalet er flyttet fra Vedlikehold › Utstyr til Nett og tilkobling › Nettverk",
            "Én bryter for automatisk opprydding: «Automatisk oppdatering og opprydding» (før var det to, og den "
            "månedlige oppryddingen trengte begge for å virke)",
        ]),
    ]),
    ("0.99.21", "Tydeligere klipp", [
        ("Spill › Klipp", [
            "Klippet du har valgt er tydelig markert: farget bakgrunn, ramme og «▶ Valgt» / «▶ Spilles nå»",
            "Mobilen: trykk på videoen for fullskjerm i liggende format (tilbake-knappen går ut igjen) – "
            "eller bruk «⛶ Fullskjerm»",
            "PC (Linux og Windows): dobbeltklikk eller ▶ spiller klippet i fullskjerm i Kontrollsenter (Esc lukker)",
            "Haket av flere klipp? De får stiplet ramme, så du ser forskjell på valgt og avhaket",
            "Mindre forhåndsbilder i klipplista på PC-en",
        ]),
    ]),
    ("0.99.20", "Chatten fryser ikke lenger", [
        ("Rettet", [
            "Kontrollsenter kunne fryse i flere sekunder om gangen når du åpnet Chat mens et spill kjørte – "
            "sjekken av hvem som spiller det samme spillet går nå i bakgrunnen (Linux og Windows)",
        ]),
    ]),
    ("0.99.19", "Ny chat og AI i mobilappen", [
        ("Android-appen – chat", [
            "Samme utseende som på PC-en: grupperte bobler, profilbilder med farge og pålogget-prikk, datoskiller, "
            "store emojier, «NYE MELDINGER»-strek og hopp-knapp, myk inn-animasjon",
            "Hold inne en melding: reaksjoner, svar, kopier, fest, rediger, slett og «Spør AI om denne»",
            "📎 Send bilder og filer · 🎙️ talemeldinger med lydbølge · lenkekort med bilde · GIF-søk",
            "/-kommandoer og @ai virker også fra mobilen · ✓✓ Lest · festet melding og «spiller nå» øverst",
            "⋯: bakgrunn per samtale, kompakt visning, Ikke forstyrr og status",
        ]),
        ("Android-appen – AI", [
            "Ny AI-fane: samme AI-er og samtaler som på PC-en (Claude, Codex, Gemini, lokal)",
            "Svaret kommer ord for ord, med «hva AI-en gjorde», kodeblokker med Kopier og forslagskort",
            "«Godta / Avbryt» rett på mobilen når AI-en vil endre noe på PC-en",
            "🎙️ Snakk inn spørsmålet (telefonens talegjenkjenning) og 🔊 få svaret lest opp",
            "Legg ved bilder, velg personlighet, fest og slett samtaler",
        ]),
    ]),
    ("0.99.18", "Ny AI", [
        ("Utseende", [
            "Svaret kommer ord for ord mens AI-en skriver",
            "Kode får farger og en «Kopier»-knapp",
            "Forslagskort når samtalen er tom – trykk for å spørre",
            "Små grå linjer viser hva AI-en gjør: «🌡️ Leste temperaturene», «⚙️ Handling: …»",
            "Eget ikon og egen farge for Claude, Codex, Gemini og lokal AI",
            "Målere for CPU, GPU, last og strøm rett under svaret når AI-en har sjekket PC-en",
            "📊 Sidepanel: PC-en nå og alt AI-en har gjort",
            "Fest samtaler øverst og gi dem en emoji (høyreklikk)",
            "Viser hvor mye av Claude-kvoten du har brukt (5 timer og uke)",
        ]),
        ("Funksjoner", [
            "«Godta / Avbryt» i samtalen før AI-en endrer noe (kan slås av i ⋯)",
            "Legg ved bilder (📎 eller Ctrl+V) – f.eks. skjermbilde av en feilmelding",
            "🔊 Les opp svar, og 🎙️ snakk inn spørsmålet (tale til tekst installeres første gang – lokalt og gratis)",
            "Personligheter: Standard, Kort og teknisk, Forklarende og rolig, Morsom",
            "Lokal AI uten nett (Ollama) – gratis og privat, bruker skjermkortet ditt",
            "Hurtigtast Ctrl+Shift+A: spør AI-en fra hvor som helst, også «Forklar det jeg har kopiert»",
            "☀️ Morgenrapport om PC-en hver dag kl. 08",
            "Automatiske oppgaver: «Si fra hvis GPU-en går over 85 °C mens jeg spiller», «Rydd hver søndag»",
            "AI-en kan lese feilloggene, se de andre PC-ene og WoW-dataene dine",
            "@ai i chatten: AI-en din svarer for alle i samtalen · «🤖 Spør AI om denne» på meldinger",
        ]),
    ]),
    ("0.99.17", "Mer i chatten", [
        ("Chat", [
            "Talemeldinger med lydbølge og lengde – virker nå også på Windows uten FFmpeg (Esc avbryter)",
            "Bilder, filer, talemeldinger, skjermdeling og «Spill sammen» også i direktemeldinger",
            "Lenker vises som kort med bilde, tittel og beskrivelse",
            "/-kommandoer: /poll, /påminn, /terning, /spill, /gif, /skjerm, /status, /stille – skriv /hjelp",
            "GIF-søk (Tenor – gratis nøkkel legges inn første gang du bruker /gif)",
            "Festede meldinger vises øverst i samtalen – trykk for å se alle",
            "«Spiller nå» øverst i serverkanaler: hvem, hvilket spill og hvor lenge – med «Bli med»",
            "🖥️ Del skjermen rett fra talelinja",
            "👍 og «✓ Lest» rett fra chatvarselet",
            "Chatten tas vare på på NAS-en hver dag (Chat-backup – de siste 14 dagene)",
        ]),
    ]),
    ("0.99.16", "Nytt utseende i chatten", [
        ("Chat", [
            "Meldinger fra samme person samles under ett navn, med rundt profilbilde (initialer i egen farge "
            "eller emojien fra profilen) og grønn/oransje prikk når de er på eller spiller",
            "Datoskiller: «I dag», «I går», «Mandag 17. nov.»",
            "Meldinger med bare 1–3 emojier vises stort",
            "Rød «NYE MELDINGER»-strek der du slapp sist, og en knapp som tar deg til bunnen",
            "Nye meldinger glir mykt inn",
            "Kompakt visning (⋯ → Visning)",
            "Egen bakgrunn per samtale – Nordlys, Solnedgang, Dyphav, Galakse, Skog, Lava eller et eget bilde",
            "Ikke forstyrr: 1 t, 2 t, 8 t, til i morgen – eller alltid når du spiller",
            "Reaksjoner, svar, rediger, slett og fest virker nå også i direktemeldinger (høyreklikk på en melding)",
            "✓ Sendt / ✓✓ Lest under din siste direktemelding",
            "Glass-stil på boblene når Flytende glass er på",
        ]),
    ]),
    ("0.99.15", "Du ser hvilken versjon du får", [
        ("Oppdateringer", [
            "«Oppdater alt» viser «Ny versjon funnet: 0.99.15 (du har 0.99.14)» under Kontrollsenter – og hvilken "
            "versjon du har når alt er oppdatert",
            "Linja på Oversikt sier «Kontrollsenter 0.99.15», og varselet nevner versjonen",
            "Fremdriftsvinduet viser «Fra 0.99.14 til 0.99.15» mens det oppdaterer",
            "Venter versjonen på testing eller omstart, står grunnen der i stedet for «Oppdatert»",
            "Gjelder Linux og Windows; Android-appen viste allerede versjonen",
        ]),
    ]),
    ("0.99.14", "Glass og Aero på mobilen – og GitHub på Windows", [
        ("Android-appen", [
            "«Liquid Glass»-temaet finnes nå også i appen",
            "Ny innstilling «Liquid Glass og Aero» (Innstillinger → Utseende): gjennomsiktig app i temaets farger "
            "der bakgrunnsbildet på telefonen skinner gjennom – uskarpt på Android 12+",
            "Velg gjennomsiktighet, uskarphet og egen farge på glasset – samme valg som på PC-en",
            "Temaene i appen lages nå automatisk fra PC-en ved hver versjon, så nye temaer alltid kommer til mobilen",
        ]),
        ("Windows", [
            "«Oppdater fra GitHub» virker uten Git – henter nyeste versjon rett fra GitHub, med sikkerhetskopi og "
            "automatisk tilbakerulling som ved oppdatering fra NAS-en (gjelder også Linux-PC-er uten Git)",
        ]),
    ]),
    ("0.99.13", "Oppdater appen fra GitHub", [
        ("Android-appen", [
            "Ny knapp «Oppdater fra GitHub» (pil ned øverst på startsiden, og under Mer → Appen)",
            "Henter nyeste app rett fra GitHub og installerer den – virker også når du ikke er hjemme og ingen PC er på",
            "Bare app-filer fra din egen GitHub-side godtas",
        ]),
    ]),
    ("0.99.12", "Glass og Aero på alle temaer", [
        ("Utseende", [
            "«Gjennomsiktig vindu (Aero)» virker nå med alle temaene – vinduet blir glass i temaets egne farger, "
            "og det bak blir mykt og uskarpt",
            "«Flytende glass» (glans og lysrefleks) og Aero er samlet i kortet «Liquid Glass og Aero» under Tema",
            "Velg om glasset skal ha temaets farge eller din egen, og hvor gjennomsiktig det skal være",
        ]),
    ]),
    ("0.99.11", "Ryddigere oppdatering", [
        ("Innstillinger → Oppdatering", [
            "Feltet for GitHub-adressen er borte – adressen ligger bak tannhjulet ⚙ og dukker opp når du trykker",
            "Ny knapp «Oppdater fra GitHub» henter nyeste versjon rett fra GitHub",
            "«Se etter oppdatering» sjekker hjemmenettet (NAS) først, så GitHub",
        ]),
        ("GitHub", [
            "Hver versjon får en nedlastingsside på GitHub med Android-appen og Windows-installasjonen",
        ]),
    ]),
    ("0.99.10", "Liquid Glass", [
        ("Utseende", [
            "Nytt tema «Liquid Glass»: hele vinduet er gjennomsiktig glass med lys kant og myk glans – du ser det "
            "som er bak",
            "Velg hvor gjennomsiktig (0–95 %) og hvilken farge glasset skal ha under Innstillinger → Utseende",
            "Uskarphet bak vinduet som Aero i Windows 7 – bare bedre (KDE Plasma og Windows 11). Kan slås av",
        ]),
        ("Vinduer", [
            "Alle vinduer som spretter opp har nå en ✕ øverst til høyre, og Esc lukker dem",
            "Funksjoner-vinduet (og andre med lange lister) ruller, så Avbryt/Bruk alltid er synlige",
        ]),
    ]),
    ("0.99.9", "Kallenavn i chatten", [
        ("Chat", [
            "Høyreklikk på en person i direktemeldingene (eller et medlem i en server) → «✏️ Gi kallenavn»",
            "Kallenavnet vises bare hos deg – i lista, tittelen, meldingene, medlemslista, talekanalen og "
            "webkamerabildene",
            "Gjelder begge systemene på en dual boot-PC, og det vanlige navnet vises i liten skrift under",
            "La feltet stå tomt for å bruke det vanlige navnet igjen",
        ]),
    ]),
    ("0.99.8", "Forlat talen – også av seg selv", [
        ("Chat", [
            "Tydelig «📞 Forlat talen»-knapp i talelinja, og «Forlat» ved talekanalen du er i",
            "✕ ved samtalene under «Samtaler» legger på og fjerner samtalen fra lista",
            "Har du vært borte i 30 minutter (ingen mus, tastatur eller prat), forlater du talekanalen eller "
            "samtalen av deg selv – med varsel. Endres under 🎛️ Lyd og video (10 min – 2 timer, eller aldri)",
        ]),
    ]),
    ("0.99.7", "«Må oppdateres» reagerer på trykk", [
        ("Rettet", [
            "Undermenyen «Må oppdateres» i chatten åpnes og lukkes med en gang du trykker (trykket ble ignorert av "
            "sperren som hindrer at lista bygges om midt i et klikk)",
        ]),
    ]),
    ("0.99.6", "Ryddigere chatliste", [
        ("Chat", [
            "PC-er med for gammel Kontrollsenter ligger under «▸ Må oppdateres» nederst i direktemeldingene – "
            "lukket som standard, ett klikk åpner",
            "En maskin der minst ett av systemene er oppdatert (dual boot) blir stående i lista, med varsel om det "
            "andre",
        ]),
    ]),
    ("0.99.5", "Dual boot: Windows og Linux på samme PC er én PC", [
        ("Samme maskin", [
            "Kontrollsenter kjenner igjen samme maskin i Windows og Linux (nettverkskortet) – og deler det med de "
            "andre PC-ene",
            "PC-er hjemme og PC-er utenfor hjemmet viser maskinen som ÉN PC, med systemene (🪟 Windows · 🐧 Linux) og "
            "hvilket som kjører nå",
            "Chatten: samme maskin er én samtale – meldinger fra begge systemene vises samlet, og nye går til systemet "
            "som er på",
            "Samme chat i begge systemene: identitet, samtaler, servere og nøkler følger med via NAS-en (hentes ved "
            "oppstart, sendes når noe endres og når Kontrollsenter avsluttes)",
        ]),
    ]),
    ("0.99.4", "Av betyr av", [
        ("Funksjoner", [
            "Når du tar bort en funksjon, slås den helt av: borte fra menyen, ingen bakgrunnsarbeid, og tjenester og "
            "autostart Kontrollsenter satte opp for den (OpenRGB, Solaar, TRCC) stoppes og fjernes",
            "Programmene funksjonen trenger avinstalleres – men bare de Kontrollsenter selv installerte. Programmer "
            "du hadde fra før får stå, og din egen autostart for dem kommer tilbake",
            "Oversikt, Historikk og Oppdateringer kan ikke tas bort, så det de trenger blir alltid værende",
            "Strømming: Sunshine installeres og fjernes sammen med funksjonen, og holdes ikke i gang når den er av",
            "Chat av: talekanal og webkamera-overlay stoppes",
        ]),
    ]),
    ("0.99.3", "Bare det du velger er på", [
        ("Funksjoner", [
            "Nye installasjoner starter med bare Oversikt, Historikk og Oppdateringer – alt annet krysses av i "
            "velkomstveiviseren, og programmene det trenger installeres da",
            "Lukker du veiviseren uten å velge, er resten av – velg og installer senere under ☰ → Funksjoner",
            "Windows-installasjonen har heller ingenting valgt på forhånd",
            "PC-er som allerede bruker Kontrollsenter beholder funksjonene sine",
        ]),
    ]),
    ("0.99.2", "Fjern alt du ikke trenger", [
        ("Funksjoner", [
            "I Egendefinert kan alt fjernes unntatt Oversikt, Historikk og Oppdateringer (nye versjoner av "
            "Kontrollsenter og «Oppdater alt» for appene er alltid med)",
            "Også Innstillinger kan skjules – den åpnes fortsatt fra ☰-menyen",
            "Ny «Funksjoner …» i ☰-menyen, så du alltid kommer tilbake til valgene",
        ]),
    ]),
    ("0.99.1", "Juster AI-siden", [
        ("AI", [
            "Dra i skillet mellom samtalelista og samtalen for å gjøre lista smalere eller bredere (huskes)",
            "Knapp øverst til venstre skjuler eller viser samtalelista – da får samtalen hele bredden",
            "⋯ → tekststørrelse (A−/A+, 70–200 %) og bredde på boblene, og «Tilbakestill utseendet»",
        ]),
    ]),
    ("0.99.0", "AI som styrer Kontrollsenter – med samtaler på NAS-en", [
        ("AI", [
            "Ser ut som iMessage: samtalene til venstre, blå og grå bobler, rundt skrivefelt med ↑",
            "Flere samtaler, og hver samtale husker det som er sagt (også fra en annen PC)",
            "Samtalene og arbeidsmappa lagres på NAS-en (Kontrollsenter/AI/<PC-navn>) – eller lokalt hvis du vil",
            "🛠️ Styrer appen (på som standard): assistenten leser temperaturer og status, endrer innstillinger, kjører "
            "systemsjekk og diagnose, og sier – og viser – hvor innstillingene ligger",
            "Endringer i innstillingsfiler tas vare på i tidsmaskinen først, så de kan angres",
            "Ny kommando «ks» i terminalen (samme muligheter – f.eks. «ks status», «ks finn vifter»)",
            "Høyreklikk på en samtale: gi nytt navn eller slett",
        ]),
    ]),
    ("0.98.0", "AI-siden: mer plass og Gemini", [
        ("AI", [
            "Valghjul for Claude Code, Codex og Gemini – status og knapper på én linje øverst",
            "Svaret fyller siden, og du skriver nederst (som i en chat) – tidligere spørsmål blir stående over",
            "Enter sender, Shift+Enter gir ny linje",
            "Gemini CLI (Google) kan installeres, logges inn og brukes på samme måte",
        ]),
    ]),
    ("0.97.0", "AI: Claude Code og Codex", [
        ("Ny meny: AI", [
            "Claude Code (Anthropic) og Codex (OpenAI) på samme side: versjon, innlogget eller ikke, installer, "
            "oppdater, logg inn og avinstaller",
            "«Åpne i terminal» starter assistenten i mappa du har valgt (med «Nylige» mapper)",
            "«Spør»: skriv et spørsmål, velg Claude Code eller Codex – svaret strømmer inn i appen (Ctrl+Enter sender, "
            "Stopp avbryter)",
            "Som standard kan AI-en bare lese; «La AI-en endre filer i mappa» må slås på",
            "Menyen er på som standard – slå den av under Innstillinger → Generelt → «AI-menyen»",
        ]),
    ]),
    ("0.96.0", "Varsler for anrop og chat, og vennene vises igjen", [
        ("Varsler", [
            "Når noen ringer: varsel med 📞 Svar, 🔕 Demp (stopper ringingen) og ❌ Legg på",
            "Varsel for nye meldinger både i servere og direkte – også når de andre varslene er slått av eller "
            "«Ikke forstyrr» er på (egen bryter: «Chat og anrop» under varslene)",
            "Ingen varsel for samtalen du allerede ser på i Kontrollsenter",
        ]),
        ("Venner", [
            "Venner som også er en PC i huset (eller er på et annet Tailscale-nett) vises igjen med status, "
            "temperaturer og spill – Kontrollsenter prøver hjemmenettet, adressene fra invitasjonen og Tailscale",
            "Nye venne-invitasjoner har med adressen på hjemmenettet",
            "Chat til venner prøver de samme adressene",
        ]),
    ]),
    ("0.95.1", "Chat begge veier mellom PC-ene hjemme", [
        ("Rettet", [
            "Meldinger til en PC hjemme som også står som venn gikk via vennens Tailscale-navn – på et annet "
            "Tailscale-nett kom de aldri frem. Nå går de over hjemmenettet først, så Tailscale, så NAS-en",
            "Meldinger som ligger i kø sendes på samme måte (de kommer frem når Kontrollsenter er startet på nytt)",
        ]),
    ]),
    ("0.95.0", "Stabil chat, ring uten server og ryddigere direktemeldinger", [
        ("Tilkobling", [
            "Chatten virker også når fjernstyring fra mobilen er av (tjenesten kjører for chatten, mobilen holdes ute)",
            "Invitasjonslenker har alle adressene (Tailscale og hjemmenettet) – den som blir med prøver alle, "
            "hjemmenettet først",
            "Meldinger til PC-ene hjemme går direkte (sekunder) i stedet for via NAS-postkassen (opptil et minutt)",
            "Raskere levering til medlemmer: adressen som virket sist brukes først",
            "Rettet: to som ble med i en server samtidig kunne skrive over hverandre (den ene forsvant)",
            "Tydelige feilmeldinger når man ikke kommer inn (gammel versjon, utløpt invitasjon, PC-en svarer ikke)",
        ]),
        ("Ring uten server", [
            "📞 i en direktemelding ringer personen – tale, webkamera og overlay som i talekanalene",
            "👥📞 Gruppesamtale: velg flere og ring alle",
            "Den som blir ringt får «📞 … ringer deg» med Svar / Avvis, og kan bli med senere fra meldingen",
            "Samtalene vises under «Samtaler» med hvem som er inne, og ryddes bort etter et døgn",
        ]),
        ("Direktemeldinger", [
            "Gruppert: Festet, Felles, PC-er hjemme og Venner",
            "PC-er med for gammel Kontrollsenter vises med «⚠️ versjon – må oppdateres»",
        ]),
        ("Mobilappen", [
            "Chat: Send-knappen får alltid plass (hurtigsvar-hjulet er smalt)",
        ]),
    ]),
    ("0.94.0", "Overlayet kan flyttes, låses og gjøres gjennomsiktig", [
        ("Webkamera-overlay i spill", [
            "Synlighet fra 0 til 100 %",
            "Lås: når den er låst, går museklikk rett gjennom til spillet",
            "Lås opp (Ctrl+Shift+O inne i spillet, eller i appen): dra overlayet dit du vil, endre størrelse med "
            "musehjulet eller −/+, og trykk 🔒 for å låse – plassering og størrelse huskes",
            "I appen: av/på, lås, hvem som vises, hjørne, bredde (120–1200 px), synlighet og «Tilbakestill plassering»",
            "Mobilkameraet kan vises i overlayet også uten talekanal",
            "Windows: overlayet ligger øverst over spill i vindu/«uten ramme», med klikk-gjennom og samme valg",
        ]),
    ]),
    ("0.93.0", "Webkamera-overlay i spill", [
        ("Overlay i spill", [
            "🖼️ i talelinjen (og under Lyd og video): vis webkameraene i et hjørne over spillet",
            "Velg «Bare meg», «Bare motparten» eller «Begge» – og slå det av og på når du vil",
            "Velg hjørne, størrelse (liten/middels/stor) og hvor synlig det skal være",
            "Ligger over fullskjermspill på KDE/Wayland, og museklikk går rett gjennom til spillet",
            "Starter av seg selv når du går inn i en talekanal (hvis det er på), og forsvinner når du går ut",
        ]),
    ]),
    ("0.92.0", "Webkamera i HD, Full HD, 1440p og 4K – opptil 120 bilder/s", [
        ("Webkamera i talekanalene", [
            "Oppløsning: 180p, 360p, HD 720p, Full HD 1080p, 1440p og 4K 2160p",
            "Bilder per sekund: 15, 24, 30, 60, 90 eller 120",
            "Koding på skjermkortet (NVIDIA NVENC eller AMD/Intel VA-API, H.264) – VP8 i prosessoren når det ikke "
            "finnes (da høyst 1080p30)",
            "Kontrollsenter spør kameraet hva det klarer og velger riktig modus (MJPEG ved høy hastighet) – ingen "
            "oppskalering; «Kameraet klarer» og «Sendes som» (med Mbit/s per deltaker) vises under Lyd og video",
            "Deltakerlista viser kvaliteten, f.eks. «📷 1080p60»",
            "Bildet fra de andre vises høyst 720p/30 på skjermen, så 4K ikke spiser minne og prosessor",
        ]),
        ("Mobilkamera", [
            "Android-appen: velg 480p, 720p HD eller 1080p Full HD med 📐-knappen",
        ]),
    ]),
    ("0.91.0", "Programmene installeres etter at du har valgt funksjoner", [
        ("Installasjon", [
            "Installasjonsskriptet (Linux) og Setup.exe (Windows) legger bare inn selve Kontrollsenter",
            "Programmene funksjonene trenger (OpenRGB, Solaar, ratbagd, TRCC, RustDesk, Tailscale, Discord, "
            "MangoHud, FFmpeg …) installeres når du har valgt funksjoner i velkomstveiviseren",
            "Fremdrift med prosent, tid igjen og nedlastingshastighet – kan kjøres i bakgrunnen",
            "Slår du av en funksjon (veiviseren eller Innstillinger → Funksjoner), fjernes programmene den brukte – "
            "med samme fremdrift",
            "Programmer du hadde fra før, fjernes bare hvis du krysser av for det (du blir spurt én gang)",
        ]),
    ]),
    ("0.90.1", "Mobilkameraet er lettere å finne", [
        ("Mobilkamera", [
            "Ny 📱-knapp i chatten på PC-en (venstre stripe og ⋯-menyen) med veiledning, «Vis i vindu», «Bruk i "
            "talekanalen» og webkamera for andre programmer",
            "Når mobilen sender, vises en linje øverst i chatten med «Vis» og «Bruk i talekanalen»",
            "«Første kamera» hopper over OBS sitt virtuelle kamera og bruker mobilen når det ikke finnes et ekte webkamera",
            "Mobilappen: «📷 Kamera» i Chat sier tydelig fra om appen eller PC-en må oppdateres, og spør om "
            "kameratilgang med en gang",
        ]),
    ]),
    ("0.90.0", "Velg funksjoner og bruk mobilen som webkamera", [
        ("Velg funksjoner", [
            "Velkomstveiviseren spør første gang: Fullstendig, Medium (uten Discord, Scener, Smart Hjem og CPU-skjerm), "
            "Minimal (Oversikt, Historikk, GPU, Lyd, Spill, Chat, PC-er, Fjernhjelp og System) eller Egendefinert",
            "Det du velger bort er helt av: borte fra menyen og søket, sidene lastes aldri, og bakgrunnsarbeidet "
            "(tidsstyrte scener, Smart Hjem-automatikk, RGB ved oppstart, chat, VR-vakt …) stopper",
            "Windows-installasjonen har de samme valgene (installasjonstype + én boks per funksjon)",
            "Endres når som helst under Innstillinger → Generelt → Funksjoner (familiekoden spørres om hvis den er på)",
        ]),
        ("📱 Mobilen som webkamera", [
            "Android-appen: Chat → 📷 åpner kameraet og sender bildet til PC-en (bytt mellom front- og bakkamera)",
            "Velg «📱 Mobilkamera» under Lyd og video for å bruke det i talekanalene",
            "Vis mobilkameraet i et eget vindu – virker også på Windows",
            "Linux: bruk det som vanlig webkamera i Discord, nettleseren og OBS (v4l2loopback, f.eks. OBS sitt "
            "virtuelle kamera)",
        ]),
    ]),
    ("0.89.0", "Talekanaler og webkamera i chatten", [
        ("Talekanaler", [
            "🔊 Nye talekanaler i serverne – trykk på kanalen for å gå inn, og alle som er der snakker sammen",
            "Se hvem som sitter i kanalen (også når du ikke er inne), hvem som snakker (grønn) og hvem som er dempet",
            "Talelinje nederst: demp mikrofonen, slå av lyden, webkamera, lyd og video, legg på",
            "📷 Webkamera: bildene til alle i kanalen vises over meldingene – klikk for større bilde",
            "Nye servere får en talekanal («lounge») med en gang",
        ]),
        ("Lyd og video (🎛️)", [
            "Velg mikrofon, høyttaler og kamera, med volum for begge veier",
            "Lydmåler, «hør deg selv», testlyd og forhåndsvisning av kameraet",
            "Støyreduksjon, automatisk forsterkning og stemmeaktivering med terskel",
            "Kvalitet (lav/middels/høy) og bilder per sekund for kameraet – endringer gjelder med en gang",
            "Taleanrop til én person bruker også mikrofonen og høyttaleren du har valgt",
        ]),
        ("Ryddigere kanaler", [
            "+ ved hver kategori: ny tekstkanal eller talekanal rett i den kategorien (også tomme kategorier)",
            "Kanallista bygges ikke lenger på nytt midt i et klikk – kanalene åpner seg første gang du trykker",
            "Større trykkflater på kanalene",
            "Skriver du tekst i ikonfeltet («🎮Gaming»), flyttes teksten inn i navnet",
        ]),
    ]),
    ("0.88.0", "Mindre minne, ryddigere chat og oppdatering for venner", [
        ("Raskere og lettere", [
            "CPU-skjerm-siden brukte 130–180 MB ekstra minne for forhåndsvisningen – nå under 30 MB, og bare mens "
            "siden vises",
            "«Mindre minnebruk» og «Eldre PC» tegner uten skjermkortdriveren (rundt 110 MB mindre)",
            "Kontrollsenters eget minne vises for seg, ved siden av minnet som deles med andre programmer",
            "Gammel og ubrukt kode er ryddet bort",
        ]),
        ("Chat", [
            "Uten Tailscale viser chatten bare «Installer Tailscale først» – med knapp som installerer det",
            "Hurtigsvar er flyttet til ⚡-hjulet ved skrivefeltet (også i mobilappen) – ikke lenger i veien over chatten",
            "⋯-menyen er delt i grupper: Lag, Del, Verktøy og Kanalen",
            "Serverikonene på stripa viser bare ikonet",
        ]),
        ("Oppdatering for venner", [
            "Venner utenfor huset får nye versjoner av Kontrollsenter (Linux, Windows og mobilappen) via PC-ene "
            "hjemme over Tailscale – sjekksummen kontrolleres før noe installeres",
        ]),
        ("Ryddigere meny", [
            "Ny seksjon «Sosialt» i sidemenyen: Chat, Discord, PC-er og Fjernhjelp",
            "Faner som ikke får plass, kan rulles sideveis i stedet for å gjøre siden bredere",
        ]),
        ("Nytt", [
            "🎁 Gratis spill denne uken: Epic Games’ gratisspill vises på Spill-siden, du får varsel når et nytt "
            "kommer, og det kan postes i en chatkanal",
        ]),
    ]),
    ("0.87.0", "Chat i mobilappen", [
        ("Nytt i mobilappen", [
            "💬 Egen Chat-fane: alle samtaler og serverkanaler, bobler, bilder, talemeldinger, avstemninger du kan "
            "stemme i, reaksjoner og hurtigsvar – med antall uleste på fanen",
            "Svar rett fra varselet: chatmeldinger kommer som varsel med «Svar»-felt",
            "Trykk på et chatvarsel for å åpne samtalen",
            "Ny widget «Chat»: de tre siste meldingene og hurtigsvar (Kommer! / 5 min til)",
        ]),
    ]),
    ("0.86.0", "Tale, kryptering og klistremerker", [
        ("Nytt i chatten", [
            "📢 Walkie-talkie: trykk og snakk – spilles av med en gang hos de andre (ikke etter leggetid)",
            "📞 Taleanrop 1-til-1: høyreklikk på et medlem → «Ring med tale» (Linux; lyden går direkte mellom PC-ene)",
            "🔒 Ende-til-ende-kryptering: meldinger i serverne krypteres for hver mottaker når begge har støtte "
            "(nye Windows-installasjoner får det også)",
            "Klistremerker: lag av et bilde og send med ett trykk (😊-menyen)",
            "Spillrom: «X spiller også CS2 – send til alle som spiller»",
            "Temakanaler: tilbud fra ønskelisten og «Oppdater alt»-resultater postes i kanalen du velger",
        ]),
    ]),
    ("0.85.0", "Chatten kobles til resten", [
        ("Nytt i chatten", [
            "Status ved navnet: 🟢 på, 🎮 spiller …, ⚫ av – og avatar og status i profilen",
            "«Spill sammen»-kort med «Bli med», lobby som sier fra når alle er klare, oppgaver med «Gjort», "
            "middagsavstemning og 🔔 Ring (ringer til den andre svarer)",
            "Hurtigsvar (Kommer!, 5 min til, Lagrer nå …) og 🆘 Hjelp / 🍕 Sulten",
            "Private meldinger og @omtaler vises inni spillet – og kan leses høyt",
            "@pc i chatten: «@pc hvor varm er du?», «@pc hvem spiller», «@pc hvor er alle» (bare spørsmål – ingen "
            "styring fra chatten)",
            "Del PC-status, del spilloppsettet ditt («Bruk»), «Vis skjermen min» (Se på) og be om hjelp",
            "🛒 Felles handleliste: skriv «+melk» i chatten",
            "Høydepunkter og ukens toppliste postes automatisk i kanalen du velger, og (valgfritt) når noen starter "
            "et spill",
            "Barnefilter, stille timer etter leggetid, blokkering, foreldrerapport (navn, ikke innhold), og en voksen "
            "må godkjenne nye servere på barnas PC-er",
            "Lim inn bilder (Ctrl+V), lenker med tittel, festede samtaler, egen lyd per person, rommet «Meg», "
            "QR-vennekode og Ctrl+Shift+C for chatten",
        ]),
    ]),
    ("0.84.0", "Chat+: bilder, tale, avstemninger og mer", [
        ("Nytt i serverkanalene", [
            "📎 Bilder og filer (opptil 8 MB) rett i chatten – klipp deles som lenke og strømmes fra PC-en som har dem",
            "🎙️ Talemeldinger: trykk for å ta opp, trykk igjen for å sende",
            "📊 Avstemninger og 📅 avtaler med svar (Kommer / Kanskje / Nei – legges også i ukeplanen)",
            "✓ sendt · ✓✓ levert · 👁 lest av, og «… skriver …»",
            "😊 Emoji-velger, ⏰ påminnelser og 🕒 «send senere» («i morgen 07:00», «om 10 min», «lørdag 18»)",
            "🎲 Terning og ✊ stein–saks–papir, 🎉 feiring ved «gg» og «gratulerer»",
            "📝 Notater per samtale, 🌐 oversett, 💨 meldinger som forsvinner og 💾 eksport",
            "🔍 Søk i all chat, og 👤 profil: navn, status, autosvar når du spiller, statistikk, minner og «mens du "
            "var borte»",
        ]),
    ]),
    ("0.83.0", "Servere i chatten – som Discord", [
        ("Nytt (Chat)", [
            "Lag egne servere (➕) med kategorier og kanaler – venner blir med via invitasjonslenke (🔗), eller du "
            "sender invitasjonen rett i en privat melding med «Bli med»-knapp",
            "Roller: eier 👑, admin 🛡️ og medlem – admin kan lage og endre kanaler og kaste ut; eieren kan gi bort "
            "eierskapet. Medlemmer kan forlate serveren når de vil",
            "Meldinger går direkte til alle medlemmene – serveren virker selv om eieren er av, og de som er av får "
            "meldingene når de er på igjen. Bare medlemmer kan skrive",
            "Høyreklikk på en melding: svar, reaksjoner (👍😂❤️😮🎉🔥), rediger, slett og fest",
            "Demp en kanal, medlemslisten ved siden av, og uleste per kanal",
        ]),
    ]),
    ("0.82.2", "Fjernhjelp i sidemenyen", [
        ("Nytt", [
            "🛟 Fjernhjelp har fått sin egen side i sidemenyen (under Hjemmet): RustDesk-ID-en din stort og tydelig, "
            "kopier, åpne eller installer RustDesk, og «Be om hjelp»",
            "Koble til en annen PC med ID – eller trykk «Koble til» på en PC hjemme (ID-ene deles automatisk)",
            "Andre programmer for fjernstyring (topp 5) samme sted",
            "Strømming handler nå bare om å spille på telefonen og TV-en",
        ]),
    ]),
    ("0.82.1", "Større rullehjul", [
        ("Bedre", [
            "Rullehjulet for valg er like bredt som valget du trykker på, med større tekst og høyere rader som følger "
            "størrelsen på vinduet – og lavere når det bare er noen få valg",
        ]),
    ]),
    ("0.82.0", "Chat for alle", [
        ("Nytt", [
            "💬 Chat i sidemenyen (under Hjemmet): chat med alle som har Kontrollsenter – «Hjemme» (familie-chatten), "
            "«Alle» (hjemme + vennene dine) og privat med hver PC og hver venn",
            "Vennene utenfor huset får meldingene direkte over Tailscale – bare de som står i vennelista di kan "
            "skrive til deg",
            "Er noen av, venter meldingen og sendes når de er på igjen (i opptil 3 døgn)",
            "Varsel ved ny melding (trykk for å åpne chatten), og antall uleste per samtale",
            "Mobilappen: velg «Alle» eller en privat samtale i chatten under Familie",
        ]),
    ]),
    ("0.81.0", "Utstyr+", [
        ("Nytt (Vedlikehold → Utstyr)", [
            "Batterihelse på bærbare (kapasitet mot ny) og ladegrense 80 % der maskinen støtter det",
            "Wi-Fi-signal med snitt og laveste siste uke",
            "Kontrollere: batteri (også Xbox-kontrollere på Windows) og varsel når det er lavt",
            "Skjermkalibrering: testmønstre for svartnivå, hvitnivå og gamma, med lysstyrke",
            "Gå tilbake til forrige systemversjon med de gamle driverne (Bazzite)",
            "Lyden følger hodesettet: går dit når det slås på, tilbake når det slås av",
            "Vent mens noen spiller: oppdateringskvelden, NAS-kopien og fartstesten venter til ingen spiller",
            "Ukens beste øyeblikk: video av ukas beste klipp søndag kveld, med beskjed til familien",
        ]),
        ("Spill+", [
            "Mus-DPI per spill (Logitech/Solaar) – settes når spillet starter, tilbake etterpå",
            "Spill på de andre PC-ene: se hvilke spill som finnes hjemme – Steam kan hente dem over hjemmenettet",
        ]),
    ]),
    ("0.80.0", "Hjem+: trygghet, mobil og stue", [
        ("Nytt", [
            "🥽 «Klar for VR» med ett trykk (VR-siden, søket og mobilappen): Max Ytelse, sjekk og fiks, start alt",
            "Vedlikehold → Trygghet og nett: be om hjelp (med RustDesk-ID), passordsjekk mot kjente lekkasjer "
            "(passordet forlater aldri PC-en), kamera og mikrofon i bruk, svindel-skjold (Quad9), nettverksvakt og "
            "fartstest (også hver natt)",
            "PC-er: «Send oppsettet mitt» (vifter, RGB, overlay, lyd, utseende …) til en annen PC, og «Ny PC? Hent "
            "oppsett» som også installerer de samme programmene",
            "Smart Hjem: QR-kode for gjeste-Wi-Fi, og lysene slukkes når PC-en går i dvale (Linux)",
            "Stue-modus viser også strømprisen, ukeplanen i dag og husets mest spilte",
            "Mobilappen: si eller skriv hva PC-en skal gjøre («demp lyden», «hvor varm er PC-en», «hvem spiller»)",
            "Familien-widgeten viser temperaturen på PC-ene",
        ]),
        ("Rettet", ["Varsel om ny enhet på hjemmenettet var aldri slått på – nå virker nettverksvakten"]),
    ]),
    ("0.79.0", "Spill+", [
        ("Nytt (Spill → Spillene → Spill+)", [
            "Spillkveld: hvem hjemme og blant vennene spiller hva – «Spill sammen» starter spillet, inviterer og blir "
            "med i Discord-kanalen",
            "Discord-kanal og lydprofil per spill – byttes når spillet starter (og lyden tilbake etterpå)",
            "Delte spillprofiler via NAS-en: startvalg og Proton som virker godt på en annen PC",
            "Spill-dagbok (første gang, lengste økt, timer-milepæler) og husets toppliste",
            "Ping-vakt: sier fra inni spillet når pingen blir dårlig – og om det er Wi-Fi/ruteren eller internett",
            "Lysshow: RGB og Hue blinker ved ace i CS2 og bosskill i WoW",
            "Forutsi spillkvelden («du pleier å spille nå»), og gjør klart om du vil",
            "Smart oppstart: lærer hvilke programmer du alltid åpner, og kan starte dem selv",
            "Ikke forstyrr i møter (Teams, Zoom, Webex) – varslene kommer samlet etterpå",
            "Retrospill fra RetroArch vises sammen med de andre spillene",
            "Finn beste FPS-grense (Linux) og Forvarm shadere – knapper du trykker selv",
            "Øktrapporten sammenligner FPS med snittet ditt, og sier fra om ny skjermkortdriver",
        ]),
    ]),
    ("0.78.0", "Familie+", [
        ("Nytt (Familie → Familie+)", [
            "Gjøremål fra ukeplanen kan krysses av – en voksen godkjenner, og det gir stjerner og ekstra spilletid",
            "Spillkø på én PC: hvem som står for tur, med beskjed inni spillet når tiden er ute",
            "Familiekonkurranse (stjerner + dager under spilletiden) med premie, og husprestasjoner for hele huset",
            "Leggetid som trapper ned: nattlys og varmt lys 30 min før, lavere lyd 15 min før, «lagre nå» 5 min før",
            "Pausevarsel inni spillet etter 3 timer (på som standard der familiekontroll er på)",
            "«Fri fra leksetid i dag» med ett trykk",
            "Bursdager: konfetti, bursdagsfarger på RGB og ekstra spilletid i gave",
            "Ukens oppsummering til barna søndag kveld, med en utfordring for neste uke",
        ]),
        ("Mobilappen", [
            "«Hvem er på nå»: hver PC med spill og spilletid i dag – «Gi 30 min» og «Pause nå», «Middag!» og "
            "«Fri fra lekser»",
            "«Middag!» trapper opp: etter 5 min dempes lyden og RGB blinker på PC-ene",
        ]),
        ("Rettet", ["Innstillinger kunne fryse et par sekunder når NAS-en var treg (PC-lista hentes nå i bakgrunnen)"]),
    ]),
    ("0.77.0", "Huset: natt, strøm og trygghet", [
        ("Nytt (Innstillinger → Automatikk → Huset)", [
            "Oppdateringskveld: én natt i uka vekkes PC-ene (Wake-on-LAN), alt oppdateres, de går i dvale igjen – "
            "rapport på mobilen",
            "Strømsparing når strømmen er dyr og PC-en står ubrukt",
            "Glemte PC-er om natten: beskjed, eller dvale automatisk",
            "Sovemodus for huset: 10 min varsel, så dvale på alle (og vekking om morgenen om du vil)",
            "Testmodus: nye versjoner prøves på én PC i 24 timer først – rulles den tilbake, får ingen andre den",
            "Strøm denne måneden per PC",
        ]),
        ("Også nytt", [
            "PC-er og mobilappen: ⏻ Vekk og 😴 Sov for hver PC",
            "Shelly-smartplugg: ekte strømmåling av hele PC-en (strøminnstillingene)",
            "Krasj og strømbrudd: Kontrollsenter merker når PC-en stoppet uten å avslutte, og hva som skjedde rett før",
            "Tidsmaskin for innstillingene: se hva som ble endret og gå tilbake (PC-assistenten)",
        ]),
    ]),
    ("0.76.0", "PC-assistenten", [
        ("Nytt", [
            "🩺 «Hvorfor treg?» på Oversikt, i søket (Ctrl+K) og i mobilappen: ser på varme, minne, prosessor, full "
            "disk, oppdateringer og skanning i bakgrunnen, strømmodus og oppetid – med fiks-knapp",
            "Spillsjekk: 20 sekunder etter at et spill starter sjekkes strømmodus, minne, disk og bakgrunnsjobber – "
            "ett varsel bare hvis noe bør fikses",
            "Lærer hva som er normalt: varsel når CPU/GPU går varmere enn vanlig ved samme last (støv) eller er "
            "varm selv i ro (kjølepasta)",
            "Diskvakt: hva som tar plass – store spill du ikke har spilt på 3 måneder, klipp og nedlastinger",
            "Levetid for SSD-ene i klartekst",
            "Ukens helserapport søndag kveld (også på mobilen)",
            "Foreslår «Eldre PC» av seg selv når vinduet hakker mye",
        ]),
    ]),
    ("0.75.0", "Eldre PC – lett grafikk", [
        ("Nytt (Innstillinger → Generelt → Ytelse)", [
            "«Eldre PC – lett grafikk»: ingen animasjoner, overganger, skygger, glød, levende bakgrunn eller "
            "minigrafer, vinduet oppdateres hvert 2. sekund og minne frigjøres når vinduet er lukket. Alle "
            "funksjonene virker. Står «anbefalt» på PC-er med få kjerner eller lite minne",
        ]),
        ("Raskere for alle", [
            "Effektnivå «Full» tegnet hele vinduet på nytt i full skjermfrekvens (179 ganger i sekundet) for den "
            "levende bakgrunnen – nå i små trinn: 6 ganger mindre tegning og 12 ganger mindre prosessor, nesten likt "
            "utseende",
            "Stue-modus, ladeikonet og bakgrunnen i mobilappen animeres på samme sparsomme måte (sparer batteri)",
        ]),
    ]),
    ("0.74.0", "Full kontroll over disk, prosessor og minne", [
        ("Nytt (Innstillinger → Generelt)", [
            "«Lagring på disk»: egen bryter for historikk, strøm, spilletid, hendelser, logg og toppverdier – av = "
            "verken skrives eller leses, bare i minnet mens programmet kjører. Bryteren finnes også på Historikk, "
            "i strøminnstillingene, på Familie og i feilloggen",
            "«Ingen lesing og skriving til disk»: slår av alt over, og oppdateringer og diskopprydding blir manuelle",
            "«Spar alt – minst mulig prosessor og minne»: minimal prosessbruk og mindre minnebruk, og alt ekstra i "
            "bakgrunnen stoppes. Slås den av, blir alt som før",
        ]),
    ]),
    ("0.73.0", "Oppdater alt med ett trykk", [
        ("Nytt", [
            "«Oppdater alt»: Kontrollsenter, programmene (Flatpak/winget), systemet med drivere, fastvare og de "
            "andre PC-ene – på Oversikt, i Innstillinger → Oppdatering og i mobilappen",
            "Bryter «Automatisk oppdatering og opprydding»: av = ingen automatiske sjekker, oppdateringer eller "
            "diskopprydding – du gjør alt selv",
            "PC-er: «Oppdater alt» og automatikk av/på for hver PC, og «Oppdater alt på alle»",
            "Funksjonene (Discord, klipp, VR, RGB, strømming, spill …) viser «Oppdatering klar» for programmet de "
            "bruker, med egen Oppdater-knapp",
        ]),
    ]),
    ("0.72.1", "WoW-addonen krasjer ikke lenger", [
        ("Rettet", [
            "WoW: Kontrollsenter Stats-addonen ga Lua-feil flere ganger i sekundet i WoW Forever, fordi nyere WoW "
            "skjuler farten («secret values») for addons. Addonen tåler nå skjulte verdier",
            "WoW: når farten er skjult, regnes distansen ut fra hvor langt du har flyttet deg i stedet",
        ]),
    ]),
    ("0.72.0", "Mindre minne og skåning av SSD", [
        ("Nytt (Innstillinger → Generelt → Ytelse)", [
            "«Mindre minnebruk»: når vinduet har vært lukket i 3 minutter, starter Kontrollsenter stille på nytt i "
            "statusfeltet – fra rundt 350 MB til rundt 120 MB. Aldri mens du spiller eller noe installeres",
            "«Mindre skriving til disk»: historikk, strøm og spilletid lagres samlet, og loggen får bare advarsler "
            "og feil – halverer det Kontrollsenter skriver til SSD/M.2",
        ]),
        ("Raskere", ["Historikken lagres uten å tvinge disken til å skrive hver gang (gjelder alle)"]),
    ]),
    ("0.71.2", "Finner hakking av seg selv", [
        ("Nytt", [
            "Windows: Kontrollsenter merker når vinduet hakker og hva som holdt det, og viser det i «Ytelse»-kortet",
            "Den månedlige oppryddingen skriver i loggen hvor mye plass den frigjorde",
        ]),
    ]),
    ("0.71.1", "Enda mindre prosessorbruk", [
        ("Raskere", [
            "Minimal prosessbruk: sensorene på Windows leses hvert 3. sekund, og i bakgrunnen samles data "
            "annethvert sekund",
        ]),
        ("Rettet", ["PC-er hjemme / venner: drivernummeret for NVIDIA på Windows vises igjen"]),
    ]),
    ("0.71.0", "Windows: raskere og jevnere", [
        ("Raskere på Windows", [
            "PowerShell-spørsmål får aldri vinduet til å stå stille: svar huskes, og vinduet får forrige svar "
            "med en gang mens et nytt hentes i bakgrunnen – også etter omstart",
            "Etter en reparasjon eller endring spør Kontrollsenter alltid på nytt",
            "Lydsiden og batterikortet spør ikke Windows når de ikke vises",
            "«Ytelse»-kortet viser hvor ofte vinduet har måttet vente",
        ]),
        ("Rettet", [
            "Windows: den månedlige oppryddingen krasjet",
            "Varsler mens du spiller kunne gi feil i bakgrunnen (og «Disken er nesten full» kom ikke)",
            "PC-er hjemme / venner: Windows-PC-er viste feil prosessornavn og manglet skjermkort, minne, "
            "hovedkort og disker",
        ]),
    ]),
    ("0.70.0", "Raskere og ryddigere", [
        ("Raskere", [
            "Spill-siden åpnes 7 ganger raskere (583 → 87 ms), Ny CPU-skjerm-siden 40 ganger (521 → 12 ms)",
            "Ingen hakk over 0,12 s når du bytter side (før: to på over 0,6 s)",
            "Rullehjulene koster ingenting lenger – vinduet skannes ikke hvert sekund",
            "Helse og panelene til mobilappen varmes opp i bakgrunnen, så appen slipper å vente",
        ]),
        ("Rettet", [
            "Knapper og hurtigkommandoer som styrer PC-en kunne gi «vinduet svarte ikke»",
            "Discord-kanaler/-chat i appen ga serverfeil uten valgt server",
            "Helsesjekken fra mobilen viste ikke lenger en fremdriftslinje på PC-en",
        ]),
        ("Ryddet", [
            "Kortere og tydeligere tekster på Discord, Familie, Opprydding, MSI, WoW, Pushvarsler og Enkel modus",
        ]),
    ]),
    ("0.69.0", "Raskere, særlig på Windows", [
        ("Nytt", [
            "Innstillinger → Generelt → «Ytelse»: se hvor mye prosessor, minne og lesing/skriving til disk "
            "Kontrollsenter selv bruker – live",
            "Bryter «Minimal prosessbruk»: ingen effekter, vinduet oppdateres hvert 3. sekund og valgfrie ting går "
            "sjeldnere – mer enn halverer prosessorbruken. Varsler, vifter og mobilappen virker som før",
            "«Åpne vinduet når PC-en starter» (på som standard) – av: bare ikon i statusfeltet",
        ]),
        ("Rettet", [
            "Windows: vinduet kom ikke tilbake etter en oppdatering (den nye trodde den gamle fortsatt kjørte). Nå "
            "venter den nye til den gamle er borte, og vinduet åpnes",
            "Windows: vinduet åpnes ved innlogging i stedet for bare ikon i statusfeltet",
            "Hakking: VR-siden og GPU-siden ventet på PowerShell i vinduet – nå i bakgrunnen",
            "Windows: effektene står på «Rolig» som standard (levende bakgrunn er tung for GTK på Windows)",
        ]),
    ]),
    ("0.68.2", "Tydelig beskjed om gamle PC-er", [
        ("Rettet", [
            "«Oppdater» på PC-er hjemme ga «svarer ikke (HTTP Error 401)» for PC-er med en versjon eldre enn 0.64. Nå står "
            "det at PC-en er for gammel til å oppdateres herfra, og den får en melding (familie-chatten) om å trykke "
            "«Oppdater» én gang – etter det virker knappen herfra",
            "«Oppdater alle PC-ene» hopper over PC-er som allerede har nyeste versjon",
        ]),
    ]),
    ("0.68.1", "Volumrullen på headsettet virker", [
        ("Rettet", [
            "Volumrullen på headsettet (og volumtastene) viste volumvinduet, men lyden endret seg ikke: standardutgangen "
            "var en annen enn den spillet og Discord brukte. Nå følger volumtastene utgangen der lyden faktisk spilles",
            "Ny bryter på Lyd-siden: «Volumtastene følger lyden» (på som standard)",
        ]),
    ]),
    ("0.68.0", "VR: WiVRn som alternativ til ALVR", [
        ("Nytt", [
            "VR-siden (Linux): velg mellom ALVR (gjennom SteamVR) og WiVRn (OpenXR rett til brillene – ofte lavere "
            "forsinkelse). Både trådløst og med kabel",
            "Sjekklisten og «Fiks alt» følger valget: WiVRn fra Flathub, Avahi, brannmur (9757 og 5353), adb og "
            "WiVRn-appen i brillene i nøyaktig samme versjon som PC-en",
            "«Start VR» starter WiVRn og – med kabel – setter opp tilkoblingen gjennom USB og åpner WiVRn i brillene. "
            "VR-vakten starter WiVRn og kabel-tilkoblingen igjen hvis de stopper",
            "Samme valg i VR-kortet i mobilappen",
        ]),
    ]),
    ("0.67.0", "Ryddig PC-app", [
        ("Nytt", [
            "Sidemenyen er ryddet fra 23 til 14 linjer: sider som hører sammen er gruppert – Spill (Spill, VR, "
            "Strømming), Utstyr (RGB, Logitech, CPU-skjerm, MSI), Nett og tilkobling (Nettverk, Wi-Fi, Bluetooth), "
            "Scener og Smart Hjem, og PC-er (hjemme og utenfor hjemmet)",
            "Øverst i en gruppe: ‹ rullehjul › for å bytte mellom sidene – som i mobilappen. Linjen i sidemenyen husker "
            "hvilken side du var på sist",
            "Lange sider er delt i kategorier med samme rullehjul: Familie (Kontroll og trygghet · Sammen · Mål og "
            "belønning), GPU-innstillinger (Skjermkortene · Skjerm og lys) og Discord (Samtalen · Lyd, mikrofon og "
            "overlay · Servere og chat · Tilkobling)",
        ]),
    ]),
    ("0.66.0", "Ryddig mobilapp", [
        ("Nytt", [
            "Hver fane i appen er delt i kategorier – velg med rullehjulet øverst (eller pilene / sveip). Bare kortene "
            "i valgt kategori vises, så du slipper å rulle langt ned. Appen husker valget",
            "Styr: PC-en · Lyd og skjerm · Scener og hjemmet · Discord. Spill: Spillene · Klipp · Prestasjoner · VR og "
            "strømming · Familie · Venner og PC-er. Verktøy: PC-verktøy · Historikk og strøm · Nett og NAS · "
            "Fjernstyring. Innstillinger: Utseende · Varsler · PC-en og appen",
            "PC-funksjonene ligger nå der de hører hjemme (spillene under Spill, radio og hjemme/borte under Styr …), "
            "og hurtigkommandoene er et rullehjul på Hjem",
            "Lange valglister (kommandoer, radiokanaler) er rullehjul i stedet for lange lister",
        ]),
    ]),
    ("0.65.0", "Mobilappen: alt fra PC-en", [
        ("Nytt", [
            "Ny seksjon «Alt fra PC-en» øverst i Verktøy i appen: hurtigkommandoer (samme som Ctrl+K), spillene med "
            "cover (start dem eller «Spill sammen»), PC-er hjemme med «Alt om PC-en» og «Oppdater alle PC-ene», "
            "PC-verktøy (ytelsestest, sikkerhetskopi, støymåler, oppstart), topp 5 programmer med installering og "
            "valg, hovedskjermkort, nettradio, hjemme/borte og versjon med «Gå tilbake»",
            "Fremdriftslinjen fra PC-en vises også i appen – prosent og tid igjen når PC-en installerer, rydder eller sjekker",
            "Stue-modus på telefonen/nettbrettet (hurtigknapp på Hjem): stor klokke, vær, temperaturer, dagens spilletid "
            "og hvem som spiller",
            "«Nytt tema hver dag» også i appen (Innstillinger → Effekter)",
            "Nye PC-funksjoner kommer automatisk i appen – PC-en beskriver kortene, appen tegner dem",
        ]),
    ]),
    ("0.64.0", "PC-er hjemme: alt om PC-en og oppdater alle", [
        ("Nytt", [
            "PC-er hjemme: «Alt om PC-en» på hver PC – live temperaturer, CPU, minne, skjermkort, hva som spilles, "
            "maskinvare og system (samme detaljer som for venner, hentet direkte fra PC-en)",
            "«Oppdater alle PC-ene»: henter nyeste versjon fra NAS-en på alle PC-ene som er på, og starter Kontrollsenter "
            "på nytt der. Er den nye versjonen allerede installert, startes den bare på nytt. «Oppdater» finnes også på "
            "hver PC som har en eldre versjon",
        ]),
        ("Rettet", ["Minnet hos venner ble vist med feil enhet"]),
    ]),
    ("0.63.0", "PC-er utenfor hjemmet", [
        ("Nytt", [
            "Ny side «PC-er utenfor hjemmet» (under Hjemmet): se vennenes PC-er – hva de spiller, FPS, CPU- og "
            "GPU-temperatur, minne og strøm. Trykk på en venns flis for alt om PC-en: prosessor, skjermkort, "
            "hovedkort, disker, driver, system og hvor lenge den har vært på – oppdateres live",
            "Del PC-en din med en vennekode: velg hva du deler (spill, temperaturer, maskinvare), kopier invitasjonen "
            "og send den. Vennene kan bare se – ikke styre noe. «Ny kode» stenger ute gamle invitasjoner",
            "PC-ene snakker direkte sammen over Tailscale – ingen skytjeneste. Del maskinen med vennen i Tailscale",
            "Venner-kort i mobilappen (Spill): trykk på en venn for detaljene, og legg til venner fra telefonen",
        ]),
    ]),
    ("0.62.0", "Hurtigkommandoer, prestasjoner og stue-modus", [
        ("Nytt", [
            "Hurtigkommandoer i søket (Ctrl+K): skriv «spillmodus», «klipp», «skjermbilde», «VR», «nattlys», «middag», "
            "en scene, et tema eller en lyd-/skjermprofil – og trykk Enter. Over 40 kommandoer",
            "«Dagen i dag» på Oversikt og i mobilappen: spilletid, mest spilte spill, klipp, strøm i kWh og kroner og "
            "varmeste temperatur",
            "🏆 Prestasjoner (Spill → Prestasjoner og i appen): 15 merker å låse opp – maraton, nattugle, 100 timer, "
            "kald hjerne, stilikon, inn i VR, lekse-helt m.fl. Du får varsel når du låser opp et nytt",
            "📺 Stue-modus (F11 eller menyen): fullskjerm til TV/andreskjerm med stor klokke, vær, temperaturer, dagens "
            "spilletid og hvem i huset som spiller – med levende bakgrunn",
        ]),
    ]),
    ("0.61.0", "18 nye temaer", [
        ("Nytt", [
            "Nå 28 temaer på PC (Linux og Windows) og i mobilappen: Cyberpunk, Galakse, Matrix, OLED-sort, Ametyst, "
            "Smaragd og gull, Koralrev, Midnattsblå, Tokyo Night, Dracula, Nord, Gruvbox, Catppuccin, Rosé Pine – og "
            "de lyse Sand, Mint, Papir og Catppuccin Latte",
            "«Nytt tema hver dag» (Innstillinger → Utseende): et nytt tema hver morgen, bare mørke eller bare lyse",
        ]),
    ]),
    ("0.60.0", "Nytt liv i utseendet", [
        ("Nytt", [
            "Levende bakgrunn som sakte driver i temaets farger – står stille når vinduet ikke er i fokus, så den "
            "ikke tar ytelse fra spill",
            "Kortene glir inn når du bytter side eller fane, knapper gir etter når du trykker, fliser løfter seg, "
            "sidemenyen glir og brytere spretter",
            "Samme effekter i mobilappen: kort som glir inn ved fanebytte, trykk-effekt og levende bakgrunn",
            "Innstillinger → Utseende → «Effekter»: Full, Rolig eller Av (også i appen)",
        ]),
    ]),
    ("0.59.3", "VR: riktig sjekk for trådløst og kabel", [
        ("Forbedret", [
            "Trådløst: sjekklisten viser «Questen funnet på Wi-Fi» i stedet for å be om USB-kabel",
            "Med kabel: «Questen koblet til med kabel» – eller «Kabel ikke koblet til» med hva du skal gjøre",
            "ALVR-appen i brillene regnes som installert når ALVR allerede kjenner brillene – ellers bare et tips",
        ]),
    ]),
    ("0.59.2", "VR: se hodesettet", [
        ("Nytt", [
            "VR-siden viser hodesettet øverst: 🔌 kabel (tilkoblet, modell og batteri) og 📶 Wi-Fi (på nettet, eller "
            "«Strømmer nå» med ALVR / Steam Link). Oppdateres hvert 5. sekund – også i mobilappen",
            "Koble Questen til med kabel én gang, så husker Kontrollsenter Wi-Fi-adressen og ser den trådløst etterpå",
        ]),
    ]),
    ("0.59.1", "VR: brannmur-rettingen virker", [
        ("Rettet", [
            "VR → «Fiks alt»: brannmur-rettingen feilet fordi sonenavnet ble lest feil («FedoraWorkstation (default)»)",
            "Brannmur-sjekken forstår nå portområder – på Bazzite/Fedora er VR-portene allerede åpne (1025–65535), så "
            "det trengs ingen endring",
            "Tydeligere feilmeldinger: avbrutt passord og feil fra firewall-cmd vises hver for seg",
        ]),
    ]),
    ("0.59.0", "Fremdriftslinje", [
        ("Nytt", [
            "Når Kontrollsenter installerer, laster ned, rydder, sjekker eller retter noe, vises en enkel fremdriftslinje "
            "nederst i vinduet: hva som skjer, prosent og omtrent hvor lang tid som er igjen. Grønn ✓ når det er ferdig",
            "Gjelder programinstallasjoner (Flathub/winget), Programmer-siden, Rydd opp, Systemsjekk, «Hvorfor er PC-en "
            "treg?», ytelsestest, støymåler, sikkerhetskopi til NAS, oppdateringer, GE-Proton og VR-oppsettet",
        ]),
    ]),
    ("0.58.0", "VR med Meta Quest 3", [
        ("Nytt", [
            "Ny side «VR» under Spill: Meta Quest 3 gjennom Steam og SteamVR – trådløst eller med kabel, på Linux og "
            "Windows. Linux: ALVR (trådløst og over USB). Windows: Steam Link (trådløst) og Meta Quest Link (kabel), "
            "eller ALVR",
            "Sjekkliste over alt som trengs – Steam, SteamVR, ALVR/Meta Link, brannmur, SteamVR-rettigheter, OpenXR, "
            "adb, ALVR-appen i brillene, videokoding og nettverk – og «Fiks alt» som installerer og retter automatisk",
            "«Start VR» starter alt i riktig rekkefølge, og VR-vakten starter ALVR, SteamVR og kabel-tilkoblingen "
            "igjen av seg selv hvis noe stopper mens du spiller",
            "VR-kort i mobilappen (Spill): start, fiks og stopp fra telefonen",
        ]),
    ]),
    ("0.57.1", "Rullehjulet følger musehjulet", [
        ("Forbedret", [
            "Rullehjulet i valgmenyene (PC og app): ett hakk på musehjulet = ett valg. Styreplate ruller fortsatt "
            "mykt og stopper på nærmeste valg",
        ]),
    ]),
    ("0.57.0", "Søk, enkel modus og ny «Hva er nytt»", [
        ("Nytt", [
            "Søk i hele Kontrollsenter: Ctrl+K (eller forstørrelsesglasset i sidemenyen) finner alle kort, brytere og "
            "valg – og hopper rett dit, med riktig fane og kortet markert",
            "Enkel modus (Innstillinger → Generelt): viser bare Oversikt, Lyd, Spill, Discord, Scener, Smart Hjem, "
            "Familie og Innstillinger. Fint på barnas PC-er – familiekoden trengs for å slå den av",
            "Ny «Hva er nytt»: det nye siden sist som kort med illustrasjon og «Vis meg»-knapp rett til funksjonen; "
            "eldre versjoner sammenfoldet og søkbare",
        ]),
    ]),
    ("0.56.0", "Mobilen: widget, snarveier og push", [
        ("Nytt", [
            "Ny widget «Spillstatus» på Android-hjemskjermen: hva som spilles nå, FPS, CPU- og GPU-temperatur, "
            "spilletid i dag – og hva de andre i huset spiller",
            "Scenene blir snarveier på app-ikonet (hold inne) – og kan brukes i Google Assistant- og Bixby-rutiner. "
            "«Hey Google, åpne Spillmodus i Kontrollsenter» virker også",
            "Pushvarsler med ntfy: varslene kommer med en gang, uten at appen er åpen og uten skytjenester – ntfy "
            "kobler seg direkte til PC-en. Slå på i Innstillinger → Varsler, og trykk «Legg til i ntfy» i appen",
        ]),
    ]),
    ("0.55.0", "Trygg på nettet og leksetid", [
        ("Nytt", [
            "Nettfilter (Familie-siden og mobilen): Cloudflare Family, CleanBrowsing eller AdGuard Family blokkerer "
            "voksen-, gambling- og skadelige sider for hele PC-en. Krever familiekoden når familiekontroll er på",
            "Leksetid: velg dager og klokkeslett – spill lukkes etter 2 minutters varsel, unntatt når «Ferdig med "
            "lekser» er godkjent i dag",
            "Meldinger rett i spillet (MangoHud på Linux): «15 minutter igjen», «5 minutter igjen – lagre spillet», "
            "«Leggetid om 10 min» og «Leksetid» – også når overlayet er skjult",
        ]),
    ]),
    ("0.54.0", "Lyd- og skjermprofiler", [
        ("Nytt", [
            "Lydprofiler (Lyd-siden): lagre utgang (høyttalere, hodesett, TV), mikrofon og volum – bytt med ett trykk. "
            "Det som spiller nå flyttes med",
            "Skjermprofiler (GPU-innstillinger): oppløsning, Hz, HDR og VRR – f.eks. «Spill» og «Film». Windows: "
            "oppløsning og Hz",
            "Nattlys og lysstyrke (GPU-innstillinger) – også eksterne skjermer via KDE (DDC/CI)",
            "Alt kan styres fra mobilen (Styr → «Lyd og skjerm») og brukes i scener: lydprofil, skjermprofil, nattlys "
            "og lysstyrke – f.eks. automatisk når et spill starter eller kl. 22",
        ]),
    ]),
    ("0.53.0", "Skjermkort og ytelse per spill", [
        ("Nytt", [
            "Spill → Bibliotek: velg skjermkort per spill (integrert eller dedikert) når PC-en har flere. Linux: "
            "legges i spillets oppstartsvalg; Windows: Windows' egen GPU-preferanse for spillets programfiler",
            "FPS-tak per spill (30–240) – sparer strøm og varme i lette spill (Linux, Windows-spill via Proton)",
            "Spillprofiler: «GPU-strøm» per spill (60–100 % av standard strømgrense) – settes når spillet starter og "
            "tilbake når det avsluttes. NVIDIA og AMD",
        ]),
    ]),
    ("0.52.0", "Tryggere oppdateringer", [
        ("Nytt", [
            "Selvtest før hver ny versjon: alle sider, faner og mobilappen åpnes automatisk, og versjonen legges ikke "
            "ut hvis noe krasjer (feilen i Innstillinger i 0.47 ville blitt stoppet)",
            "Starter en ny versjon ikke, går PC-en tilbake til forrige versjon av seg selv – nå for alle oppdateringer, "
            "ikke bare den nattlige. Krasjer den med en gang, skjer det umiddelbart",
            "Innstillinger → Oppdatering: «Gå tilbake til forrige versjon» med ett trykk",
            "Feil sendes til NAS-en (Diagnose) hver halvtime når det har kommet nye – og Vedlikehold → Feilsøking → "
            "«Feil fra PC-ene i huset» viser dem for alle PC-ene",
        ]),
    ]),
    ("0.51.0", "Velg skjermkort", [
        ("Nytt", [
            "GPU-innstillinger → «Hovedskjermkort» (når PC-en har flere skjermkort): velg Automatisk, integrert eller "
            "dedikert – eller mellom flere dedikerte. Viser hvilket kort skjermen er koblet til",
            "Advarsel om at skjermkabelen må sitte i kortet du velger, ellers blir skjermen svart",
            "Linux (KDE): byttet skjer ved neste innlogging, og bare hvis det valgte kortet har en skjerm koblet til – "
            "ellers starter skrivebordet som vanlig, så du aldri står uten bilde",
            "Windows: de andre skjermkortene slås av, og byttet angres av seg selv hvis du ikke trykker «Behold» "
            "innen 20 sekunder",
        ]),
    ]),
    ("0.50.0", "Velg program i hver funksjon", [
        ("Nytt", [
            "Øverst i hver funksjon: «Program» – velg hvilket av de installerte programmene du vil bruke, og bytt når du "
            "vil (f.eks. Medal ↔ Xbox Game Bar). «Åpne» starter programmet, og «Flere programmer – topp 5» lar deg "
            "installere flere",
            "Klipp følger valget: på Windows trykker «Lagre klipp» og F8 tasten til Medal, NVIDIA App (Alt+F10), OBS, "
            "Steam eller Game Bar. Tasten kan endres per program. På Linux stoppes Kontrollsenters eget opptak når du "
            "velger et annet program, så det ikke tas opp dobbelt",
            "Spill-launcheren: «Vis spill fra» – alle, eller bare Steam / Heroic / Lutris",
            "Fjernstyr-knappen på mobilen åpner programmet du har valgt (RustDesk, AnyDesk, TeamViewer, Parsec …)",
        ]),
    ]),
    ("0.49.0", "Topp 5 programmer per funksjon", [
        ("Nytt", [
            "Hver funksjon som trenger et program viser de fem beste valgene, rangert fra 1 til 5 – eget for Linux og "
            "Windows: spillbutikker, tale og chat, RGB, mus og tastatur, klipp, redigering, strømming, fjernstyring og VPN",
            "Merket «styres fra Kontrollsenter» på programmene Kontrollsenter kan styre direkte. Installer med ett trykk "
            "(Flathub/winget), eller «Nettside» der programmet må lastes ned fra produsenten",
            "Samlet oversikt i Innstillinger → Generelt – funksjoner som mangler program er slått opp",
        ]),
        ("Rettet", [
            "Innstillinger åpnet seg ikke (feil fra 0.47)",
        ]),
    ]),
    ("0.48.0", "Medal og «Se på» som virker", [
        ("Nytt", [
            "Windows: Medal brukes til klipp i stedet for Xbox Game Bar (kan byttes under Spill → Klipp). Mangler Medal, "
            "kommer «Installer Medal». Medal eier F8 selv, «Lagre klipp» i appen og på mobilen trykker Medals tast, og "
            "klippene vises fra Medal-mappen (finnes av seg selv, eller velg den)",
        ]),
        ("Rettet", [
            "«Se på» på Linux ga svart skjerm med en tynn strek: bildet hentes nå med GPU Screen Recorder (samme som "
            "klippene), som leser skjermkortets bilde riktig – også på NVIDIA. Første bilde kommer etter ca. 1,5 sekunder",
            "Gjenkjenner svarte bilder og prøver neste metode av seg selv, og husker metoden som virket",
        ]),
    ]),
    ("0.47.0", "Riktig program til hver funksjon", [
        ("Nytt", [
            "Funksjoner som trenger et program viser «Installer …» rett i funksjonen når programmet mangler – med det "
            "beste valget for Linux (Flathub) og Windows (winget): Spill-launcheren (Steam, Heroic, Lutris, Battle.net), "
            "Discord, RGB (OpenRGB), Logitech (Solaar / G HUB), klipp (GPU Screen Recorder, FFmpeg), Strømming "
            "(Sunshine, Moonlight) og fjernstyring (RustDesk)",
            "Ny oversikt i Innstillinger → Generelt: alle programmene funksjonene bruker, hva de er til, og om de er "
            "installert",
            "Alle installasjoner går nå samme vei, og programmer som er installert på andre måter blir funnet",
        ]),
    ]),
    ("0.46.0", "Familieplan og belønningsbutikk", [
        ("Nytt", [
            "Felles ukeplan (Familie-siden og mobilappen): legg inn avtaler som «Fotballtrening tirsdag 17:30». Planen "
            "ligger på NAS-en, og hver PC varsler 15 minutter før – også midt i et spill – så man rekker å lagre",
            "Belønningsbutikk: godkjente mål gir stjerner (1 ⭐ per 5 minutter). Stjernene løses inn mot ekstra "
            "spilletid, å velge middag eller film, være oppe lenger i helgen m.m. – en voksen godkjenner",
            "Ny varseltype «Ukeplan» under Innstillinger → Varsler",
        ]),
    ]),
    ("0.45.0", "Smartere hjem", [
        ("Nytt", [
            "Hjemme/borte (Smart Hjem → Automatikk): velg telefonene i huset, så kan scener slå seg på «Når noen kommer "
            "hjem» eller «Når alle har dratt». Alt skjer lokalt på hjemmenettet",
            "Strømpris-smart: ny scene-utløser «Når strømmen er billigst i natt», og den ukentlige sikkerhetskopien til "
            "NAS-en kjøres i den billigste timen mellom 22 og 07",
            "Nettradio rett på Chromecast/Nest: NRK P1, P2, P3, mP3, Klassisk og Jazz – høyttaleren spiller selv, så "
            "PC-en kan slås av. Egne kanaler kan legges i radio.json",
        ]),
    ]),
    ("0.44.0", "Mobilen mens du spiller", [
        ("Nytt", [
            "Levende varsel på telefonen mens et spill kjører: spillet, FPS, CPU-/GPU-temperatur og spilletid i dag – "
            "også på låseskjermen, med knapp for «Lagre klipp». Stopper av seg selv når spillet avsluttes",
            "Får du ikke varselet med en gang, kommer et «Trykk for live-status»-varsel når PC-en begynner å spille",
            "Ny hurtigknapp «Del klipp» på Hjem: deler det siste klippet med ett trykk (Snap, Messenger osv.)",
            "Ny hurtigknapp «Fjernstyr»: kopierer PC-ens RustDesk-ID og åpner RustDesk-appen på telefonen",
        ]),
    ]),
    ("0.43.0", "PC-verktøy", [
        ("Nytt", [
            "Oppstartsrapport (Vedlikehold → System): hvor lang tid PC-en bruker på å starte, hva som tar mest tid, og "
            "konkrete tips (f.eks. «Fast Boot» i BIOS eller utsette Sunshine)",
            "Trygg ytelsestest: måler prosessor (én og alle kjerner), minne og disk og sammenligner med forrige gang – "
            "endrer ingenting på maskinvaren (i stedet for overklokking)",
            "Støymåler for viftene (Linux): mikrofonen lytter mens viftene går på 30–100 %, og du får vite hvor raskt "
            "de kan gå før de bråker. Viftene settes tilbake til auto etterpå",
            "Sikkerhetskopi til NAS-en (Vedlikehold → Gjenoppretting): skjermbilder, klipp og dokumenter – bare nye og "
            "endrede filer, med automatikk hver uke",
        ]),
    ]),
    ("0.42.0", "Spill-launcher", [
        ("Nytt", [
            "Ny fane «Spillene» under Spill: alle spillene dine med cover-bilder – Steam, Heroic (Epic/GOG) og Lutris "
            "(f.eks. Battle.net). Ett trykk starter spillet, og scener, tema og spillprofil for spillet slår seg på av seg selv",
            "«Spill sammen»: trykk på personer-knappen på et spill, så får de andre PC-ene i huset et varsel – trykker de "
            "på det, starter samme spill hos dem og du får beskjed om at de blir med",
            "YouTube og Twitch i nettleseren telles som skjermtid i spilletiden og familiegrensene (Linux). Kan slås av "
            "på Familie-siden (krever familiekoden når familiekontroll er på)",
            "Høydepunkt-klipp i CS2 ved 3+ kills eller ace lagres fortsatt av seg selv",
        ]),
    ]),
    ("0.41.0", "Discord: servere og chat", [
        ("Nytt", [
            "Discord-siden viser nå serverne du er med i og kanalene på hver server. Trykk på en tekstkanal for å lese "
            "chatten – den oppdateres av seg selv, med navn i fargene fra Discord og dine egne meldinger til høyre",
            "«Åpne i Discord» / «Svar i Discord» åpner kanalen rett i Discord-appen (på PC-en og telefonen)",
            "I appen: «💬 Servere og chat» i Discord-kortet under Styr",
            "Merk: Discord tillater ikke at andre programmer sender meldinger som deg eller viser vennelisten din – "
            "det ville krevd innloggingsnøkkelen din og bryter vilkårene deres. Har du koblet til før: trykk «Koble "
            "til på nytt» én gang, så får Kontrollsenter lov til å lese chatten",
        ]),
    ]),
    ("0.40.1", "Glød på flisene", [
        ("Nytt", [
            "Flisene og kortene i Oversikt, kortene på sidene og scenekortene gløder nå som knappene: en lysende kant "
            "i temaets farger når musa er over, og et mykt lys som følger pekeren",
            "I appen: flisene, snarveiene, scenene, Discord-knappene og målene lyser opp der fingeren trykker, med glød "
            "rundt – og følger musa på nettbrett/PC",
        ]),
    ]),
    ("0.40.0", "Rullehjul og Discord", [
        ("Nytt", [
            "Alle valgmenyer er nå et rullehjul – som den gamle iPhone-velgeren, men med flytende glass: valgene ligger "
            "på en sylinder som snurrer, det valgte står i et lysende glassbånd og hjulet snapper mykt på plass. Rull, "
            "dra, trykk eller bruk piltastene. Også i mobilappen, med et lite tikk for hvert valg",
            "Ny side «Discord» (under Spill) og et Discord-kort i appen (Styr): mikrofon av, lyd av og forlat samtalen "
            "med ett trykk, og hvem som er i samtalen",
            "Med full tilkobling til Discord: mikrofonvolum, volum på samtalen, valg av mikrofon og høyttalere, "
            "stemmeaktivering eller trykk for å snakke, støydemping, ekkodemping og automatisk forsterkning",
            "Uten oppsett styres Discord via lydsystemet: Discord-volum, mikrofon av og lyd av",
            "Overlay: Discord har ikke eget overlay på Linux – knappen slår på spill-overlayet i Kontrollsenter i stedet",
        ]),
    ]),
    ("0.39.0", "Ytelse og vedlikehold", [
        ("Nytt", [
            "«Hvorfor er PC-en treg?» – én knapp (Vedlikehold → Feilsøking, og i appen under Verktøy) som ser på "
            "prosessor, minne, disk, temperatur, strømmodus og oppdateringer i bakgrunnen, forklarer hva som er galt og "
            "har en knapp for å fikse det (avslutt programmet, kraftigere vifter, bytt strømmodus)",
            "Automatisk opprydding én gang i måneden – bare det som er helt trygt (miniatyrbilder og shader-cache for "
            "spill som ikke er installert; på Windows også midlertidige filer). Aldri papirkurven eller filene dine. "
            "Rapport som varsel og i Vedlikehold → Rydd opp",
            "Overvåking av FPS-dropp: når FPS-en faller kraftig mens du spiller, lagres hva som skjedde – temperaturer, "
            "belastning og hva som kjørte. Øktrapporten sier hvor mange dropp det var og den vanligste årsaken, og "
            "detaljene står under Spill → Statistikk",
        ]),
        ("Rettet", [
            "Feil på Logitech-siden (Solaar-enheter) når kortene ble bygd på nytt",
        ]),
    ]),
    ("0.38.0", "Familie og spill", [
        ("Nytt", [
            "Ukesrapport søndag kveld: spilletid per person, mest spilte spill, antall økter, lengste økt og strøm – for "
            "alle PC-ene i huset. Også som kort på Familie-siden og i appen (Spill)",
            "Mål og belønning: «Ferdig med lekser», «Ryddet rommet», «Gått tur» og «Hjulpet til hjemme». Barna trykker, "
            "foreldrene får varsel på telefonen og godkjenner – ekstra spilletid kommer med en gang. På PC-en krever "
            "godkjenning familiekoden når familiekontroll er på",
            "Ranking på tvers av PC-ene: mest spilt denne uka, flest økter, lengste økt og flest CS2-kills – i tillegg til "
            "K/D og WoW-levels. Vises på Familie-siden og i appen",
        ]),
    ]),
    ("0.37.0", "Smart Hjem-automatikk", [
        ("Nytt", [
            "Hue-lysene følger spillet: når et spill starter, får lysene spillets farge – og settes tilbake slik de var "
            "når du avslutter",
            "TV-en slås av når PC-en går i hvilemodus eller slås av (Linux) – Kontrollsenter ber om et par sekunder "
            "så den rekker det",
            "Synk RGB og Hue: lysene i rommet og i PC-en har alltid samme farge, enten du endrer i Kontrollsenter "
            "eller i Hue-appen",
            "Slås på øverst på siden Smart Hjem. Scenene fra forrige versjon kan fortsatt gjøre alt på én gang",
        ]),
    ]),
    ("0.36.0", "Mobilappen", [
        ("Nytt", [
            "Ny widget «Velg selv»: fire fliser du velger – CPU/GPU-temperatur, strømforbruk, ping, strømpris nå, været, "
            "spilt i dag, kWh i dag, batteri eller neste avtale. Hold på widgeten → Innstillinger for å bytte",
            "Nye hurtigfliser (sveip ned – virker også fra låseskjermen): «Demp PC-en» og «Middag!»",
            "Nye snarveier på app-ikonet (hold fingeren på ikonet): Spillmodus, Demp PC-en, Middag! og Lås PC-en. Dra dem "
            "ut på hjemskjermen, eller bruk dem i Bixby-rutiner",
            "Klokka (Wear OS / Galaxy Watch): varslene fra Kontrollsenter – temperatur, batteri, chat og «Middag!» – "
            "vises på klokka når telefonen viser dem",
        ]),
    ]),
    ("0.35.0", "Smartere varsler", [
        ("Nytt", [
            "«Musa er fulladet» – varsel når mus, headset eller tastatur er ferdig ladet, så du kan ta ut kabelen",
            "Øktrapporten etter et spill sier fra når du har satt rekord: «🏆 lengste økt denne uka» eller "
            "«🏆 beste FPS denne uka»",
            "Diskhelse: én gang i døgnet sjekkes SMART – du får varsel hvis disken nærmer seg slitt eller har feil",
            "Varsel hvis prosessoren eller skjermkortet blir mye varmere på under ett minutt uten at noe jobber "
            "(vifte som har stoppet, støv …)",
            "Mens du spiller holdes varslene tilbake – du får ett samlet varsel når spillet er ferdig. Familie-chat og "
            "spilletid kommer likevel. Kan slås av i Innstillinger → Varsler",
        ]),
    ]),
    ("0.34.0", "Flere fliser", [
        ("Nytt", [
            "Nye fliser i Oversikt: ping, nedlasting, spilletid i dag, strømpris nå (med billigste time), været og neste "
            "kalenderavtale. Sted, strømprisområde og kalender velger du i Innstillinger → Generelt",
            "Minigraf for siste minutt rett i CPU-, GPU-, strøm-, ping- og nedlastingsflisen",
            "Oppsett: Standard, Spill, Jobb og Natt – hvert oppsett husker sine egne fliser, rekkefølge og størrelser. "
            "«Spill» velges av seg selv mens du spiller, og byttes tilbake etterpå",
            "Skjul fliser du ikke trenger (✕ i tilpass-modus eller høyreklikk) – og hent dem fram igjen med «Vis skjulte»",
        ]),
    ]),
    ("0.33.0", "Levende temaer", [
        ("Nytt", [
            "Tema etter tid på døgnet: Arktis om morgenen, Solnedgang om kvelden og Nordlys om natten (du velger tider og "
            "temaer). På PC-en glir fargene sakte over i det neste temaet de siste 20 minuttene",
            "Tema som følger spillet: velg et tema per spill – når spillet starter, bytter Kontrollsenter tema og RGB-lysene "
            "i PC-en får samme farge. Alt går tilbake når du avslutter",
            "Eget tema: velg to farger selv, eller la Kontrollsenter hente fargene fra skrivebordsbakgrunnen din",
            "Levende bakgrunn: gløden beveger seg sakte og lyser sterkere når PC-en jobber hardt (PC og app)",
        ]),
        ("Rettet", [
            "Kortene på sidene fikk tom luft nederst etter at de ble flyttbare",
        ]),
    ]),
    ("0.32.0", "Scener", [
        ("Nytt", [
            "Scener: én knapp som setter hele rommet og PC-en på én gang – strømmodus, vifter, RGB, Hue-lysene, "
            "Samsung-TV-en, lyden, fargetemaet og varslene. Fem ferdige: Spillkveld, Etter spillet, Filmkveld, Fokus og "
            "God natt – og du kan lage dine egne",
            "Scener kan slå seg på av seg selv: når et spill starter, når det avsluttes, eller hver dag på et klokkeslett",
            "Ny side «Scener» under Hjemmet på PC-en, og et Scener-kort øverst i Styr i mobilappen",
            "«Ingen varsler» i en scene holder varslene unna til en annen scene slår dem på igjen (familie-chat og "
            "spilletid slipper fortsatt gjennom)",
        ]),
    ]),
    ("0.31.0", "Temaer", [
        ("Nytt", [
            "Ti fargetemaer på PC-en (Linux og Windows) og i mobilappen: Nordlys, Synthwave, Solnedgang, Dyphav, Skog, "
            "Midnatt og gull, Lava, Kirsebærblomst, Arktis – og det gamle Kontrollsenter. Hvert tema farger alt: "
            "bakgrunnen med glød, kortene, sidemenyen, knappene, bryterne, grafene og det som er «på»",
            "PC-en: Innstillinger → Utseende. Temaet byttes med en gang, uten omstart",
            "Appen: Innstillinger → Utseende. Temaet glir over på et øyeblikk og gjelder også startskjermen og alle PC-ene",
        ]),
    ]),
    ("0.30.5", "Musa blir værende", [
        ("Rettet", [
            "Musa kunne fortsatt forsvinne når ladekabelen ble tatt ut og satt i igjen, fordi UPower mistet den. Nå leses "
            "batteriet også rett fra Linux-kjernen, så musa vises alltid – med «⚡ Lader · 70 %» mens den lader, enten "
            "den lader trådløst via mottakeren eller står koblet med kabelen",
        ]),
    ]),
    ("0.30.4", "Mus i ladekabelen", [
        ("Rettet", [
            "En Logitech-mus (f.eks. PRO X2 SUPERSTRIKE) forsvant fra batterilisten når ladekabelen ble satt i – den "
            "snakker da direkte over USB i stedet for via mottakeren. Nå vises den som «⚡ Lader · 68 %», og nivået "
            "oppdateres hvert 8. sekund mens den lader (via Solaar)",
        ]),
    ]),
    ("0.30.3", "Lading med en gang", [
        ("Rettet", [
            "Når du setter inn eller tar ut laderen, endres batteriet med en gang: mus og tastatur (UPower sier fra "
            "umiddelbart) og hodesett (sjekkes hvert 4. sekund). Før kunne det ta opptil halvannet minutt",
        ]),
    ]),
    ("0.30.2", "Lading", [
        ("Nytt", [
            "Enheter som lader viser et grønt, pulserende lyn og «Lader · 64 %» – på PC-en, i appen, i detaljene og i "
            "widgetene (skrivebord, KDE og Android). Fulladet vises med støpsel og «Fulladet · 100 %»",
        ]),
        ("Rettet", [
            "Batterier-kortet i appen var borte etter at Hjem ble ombygd – nå ligger det blant flisene igjen. "
            "Feilen stoppet også resten av familie- og knappebord-funksjonene i appen",
            "Hodesett som ikke oppgir nivå mens de lader, viste «-1 %»",
        ]),
    ]),
    ("0.30.1", "Batteri i hodesettet", [
        ("Rettet", [
            "«Installer» i Batterier-kortet feilet fordi Homebrew ikke lenger har HeadsetControl. Nå hentes ferdig "
            "versjon rett fra HeadsetControl på GitHub – på både Linux og Windows. Da vises batteriet i hodesett som "
            "Logitech G PRO X 2 LIGHTSPEED",
        ]),
    ]),
    ("0.30.0", "Flytt og endre alt", [
        ("Nytt", [
            "Alle kort i alle fanene kan nå få ny størrelse, ikke bare på Hjem: S, M og L. I appen: hold fingeren på et "
            "kort (Styr, Spill, Verktøy, Innstillinger) og trykk S/M/L i hjørnet. På PC-en: høyreklikk på et kort, eller "
            "velg «Vis S / M / L i hjørnet»",
            "PC-en: kortene på alle sidene ligger nå i samme rutenett som Oversikt – dra for å flytte, og små kort "
            "legger seg ved siden av hverandre",
        ]),
        ("Rettet", [
            "Appen: langt trykk virket bare på overskriften i kort som er fulle av knapper (Styr, Spill, Verktøy, "
            "Innstillinger). Nå virker det også på knappene – trykket på knappen blir ikke utført",
        ]),
    ]),
    ("0.29.0", "Flytt på alt", [
        ("Nytt", [
            "PC-en: dra et hvilket som helst kort på alle sidene til en ny plass med musa – Spill, Vedlikehold, "
            "Innstillinger, Nettverk, Lyd, GPU, RGB, Logitech, CPU-skjerm, Familie, PC-er hjemme, Smart Hjem, Historikk og "
            "resten. Målet lyser lilla, kortet spretter på plass, og rekkefølgen huskes",
            "Appen: hold fingeren på et kort i hvilken som helst fane (Hjem, Styr, Spill, Verktøy, Innstillinger) og dra "
            "det dit du vil – også snarveiene øverst på Hjem. «Tilbakestill» setter fanen tilbake",
            "Startskjermen i appen: hold fingeren på en PC, en TV/høyttaler eller en enhet i Smart Hjem for å flytte den",
        ]),
    ]),
    ("0.28.1", "Alle flisene", [
        ("Nytt", [
            "Alle flisene og kortene i Oversikt kan nå trykkes på for detaljer – også Strømmodus, Vifter (hver vifte, "
            "turtall over tid og styring), Helse (hele systemsjekken) og Maskin (system, hovedkort, BIOS, grafikk, disker)",
        ]),
        ("Rettet", [
            "Lange forklaringer i detaljene vises under tittelen i stedet for å klemme den",
            "Detaljarket i appen er ikke lenger gjennomsiktig med flytende glass i lyst tema",
        ]),
    ]),
    ("0.28.0", "Din egen oversikt", [
        ("Nytt", [
            "Oversikt kan ordnes som du vil – på PC-en og i mobilappen: dra flisene og kortene til nye plasser. "
            "Flisen løftes når du drar, de andre glir unna, og den «spretter» på plass med en lilla glød når du slipper",
            "Velg størrelse på hver flis og hvert kort: S, M, L (og XL i appen). På PC-en: trykk på rutenett-knappen øverst "
            "eller høyreklikk på et kort. I appen: hold fingeren på en flis",
            "Trykk på en flis eller et kort for mye mer info: graf for de siste 10 minuttene, nøkkeltall, hver tråd, "
            "hva som bruker mest CPU og minne, alle disker, nettverkskort med IP, alle temperaturer, strømkostnad og batterier",
            "Velg hvilke varsler du vil ha – eller slå av alle: Innstillinger → Varsler på PC-en. I appen kan du "
            "velge både hva PC-en varsler om og hva telefonen varsler om (Innstillinger)",
        ]),
        ("Endret", [
            "Batterier, Strømmodus og Vifter er nå kort i Oversikt som kan flyttes på, og 1 min / 10 min / 1 time for "
            "grafene ligger øverst",
            "Hovedbryteren for varsler slår nå av alle varsler (også chat, klipp og spilletid). Spilletid og leggetid "
            "vises alltid når familiekontroll er på, og «noen ser på skjermen din» vises alltid",
        ]),
    ]),
    ("0.27.0", "Ryddet opp", [
        ("Endret", [
            "Ny side «Innstillinger» nederst i sidemenyen – alt du stiller inn i Kontrollsenter er samlet der i faner: "
            "Generelt (oppstart, bakgrunn, glass og språk), Varsler, Automatikk (stille om natten), Widgets, "
            "Mobil (mobilappen, fjernstyring og «Del denne PC-en») og Oppdatering (oppdatering og sikkerhetskopi)",
            "«Verktøy» heter nå «Vedlikehold» og har faner: System, Rydd opp, Gjenoppretting og Feilsøking "
            "(med Systemsjekk)",
            "Spill har fått faner: Statistikk, Klipp, Bibliotek, Spillprofiler og Kontrollere. Spillprofiler er flyttet "
            "hit fra Automatikk",
            "Sidemenyen er ryddet: Familie, PC-er hjemme og Smart Hjem ligger sammen under «Hjemmet», og siden "
            "«Automatikk» er borte (innholdet ligger i Spill og Innstillinger)",
            "Sidene husker hvilken fane du var på sist",
        ]),
    ]),
    ("0.26.0", "Smart Hjem", [
        ("Nytt", [
            "Ny side «Smart Hjem» på PC-en: finner alle enhetene på hjemmenettet – lys, TV-er, Chromecast/Nest, "
            "høyttalere, konsoller, NAS, ruter og resten – og sorterer dem etter type. Gi dem navn ved å trykke på dem",
            "Styr Philips Hue (alle lys, rom, hvert lys med lysstyrke og farge), Samsung-TV (av/på, volum, demp, hjem, "
            "kilde, pause/spill) og Chromecast/Google Nest (hva som spilles, volum, demp, pause, stopp)",
            "Android-appen: ny fane «Smart Hjem» nederst på startskjermen ved siden av «PC-er» – hentes fra en PC som er på",
        ]),
        ("Endret", [
            "Startskjermen i Android-appen er ryddet: fanelinje nederst, små verktøyknapper (Søk, Legg til, Spill) "
            "og mindre tekst",
        ]),
    ]),
    ("0.25.0", "Lilla betyr «på»", [
        ("Endret", [
            "Lilla betyr nå alltid at noe er slått på – på PC-en, i appen og på startsiden i Android-appen. "
            "Vanlige knapper (Lagre, Åpne, Søk …) er ikke lenger lilla hele tiden, men lyser lilla mens du holder på dem",
            "Vifter: 50 % og Maks blir lilla når viftene står slik (som Auto og Kurve)",
            "«Slå av senere»: tiden du valgte er lilla til avslåingen er avbrutt",
            "Snarveiene (Spillmodus, Demp av/på, Vifter maks og Vifter auto) blir lilla når de er på",
            "Tasten for klipp: valgt tast er lilla",
        ]),
        ("Rettet", [
            "Med glass-utseendet på PC-en ble knapper som var slått på ikke lilla",
        ]),
    ]),
    ("0.24.3", "Lilla også på hjemmeskjermen", [
        ("Endret", [
            "Android-widgeten «Hurtigknapper»: Demp blir lilla når lyden er dempet (som Spillmodus), "
            "og et nytt trykk slår lyden på igjen",
        ]),
    ]),
    ("0.24.2", "Lilla når det er på", [
        ("Endret", [
            "Alle knapper som er slått på blir nå lilla – på PC-en og i appen på mobil og nettbrett, "
            "akkurat som «Auto» på viftene (f.eks. dempeknappen, profiler, tidsrom i grafene og stjerner)",
        ]),
    ]),
    ("0.24.1", "Alt om WoW på ett sted", [
        ("Endret", [
            "Spill: alt om World of Warcraft er samlet i ett kort rett under statistikken – karakterene, bagsøk, mål og "
            "«Innstillinger for WoW» (alle brytere, også klipp av boss-kills og dødsfall)",
        ]),
        ("Nytt", [
            "Oppdateringsknapp på statistikken i appen – henter ferske tall for alle spill (WoW, Steam og CS2). "
            "På PC-en oppdaterer knappen også WoW-kortet",
        ]),
    ]),
    ("0.24.0", "WoW: egenskaper, talenter og råd", [
        ("Nytt", [
            "Ny fane «Egenskaper og talenter» under WoW-statistikken – i appen og på PC-en: Armor, Strength, Agility, "
            "Stamina, Intellect, Spirit, Attack/Spell Power, Crit, Hit, Defense, motstand og talentfordelingen",
            "Råd ut fra klasse og spec: hva du bør prioritere, ubrukte talentpoeng, for lite Hit/Spell hit/Defense på "
            "level 60 og om du har mer av en egenskap som gir lite for spec-en din",
            "Kan slås av under Spill → World of Warcraft → «Egenskaper og talenter». Skriv /reload i WoW etter oppdateringen",
        ]),
    ]),
    ("0.23.0", "Mer World of Warcraft – i appen og på PC-en", [
        ("Nytt", [
            "Varsel på telefonen når noen hvisker til deg i WoW, inviterer deg til en gruppe eller nevner deg i guild-chatten",
            "Oversikt over alle karakterene: level, gull, hvor de er og uthvilt XP (regnes ut fram til nå, også når du ikke spiller)",
            "Søk i bagger og bank på alle karakterene («Hvor ligger Linen Cloth?»)",
            "Questloggen, yrker med fremgang, raid- og dungeon-låser og gull over tid per karakter",
            "Varsel når utstyret må repareres og når et yrke må læres videre hos treneren",
            "WoW-skjermbildene kommer i skjermbildene i Kontrollsenter, klare til å deles",
            "Alt kan slås av – én bryter for alt og én per funksjon (Spill → World of Warcraft). "
            "Bare lesing av det WoW og addonen lagrer, ingen automatisering. Skriv /reload i WoW etter en endring",
        ]),
    ]),
    ("0.22.3", "WoW-statistikken oppdateres igjen", [
        ("Rettet", [
            "WoW-statistikken låste seg når en karakter gikk opp i level, så nye tall og karakterer kom aldri fram",
            "En ny karakter med samme navn som en slettet arver ikke lenger den gamles statistikk (addonen kjenner "
            "igjen karakteren på ID-en)",
        ]),
        ("Nytt", [
            "Appen: «Fjern fra listen» på WoW-karakterer du har slettet. Spiller du med den igjen, kommer den tilbake",
        ]),
    ]),
    ("0.22.2", "Samme farge sendes på nytt", [
        ("Rettet", [
            "RGB: et trykk på fargen som allerede er valgt under «Alle enheter» gjorde ingenting. Nå sendes den på nytt "
            "til alle enhetene – nyttig når tastatur, mus eller andre lys har kommet ut av takt",
        ]),
    ]),
    ("0.22.1", "CPU-kjøleren lyser i fast farge", [
        ("Rettet", [
            "RGB: med en fast farge (f.eks. grønn) ble lys på hovedkortets uttak – som CPU-kjøleren – slått av. "
            "Fargene ble sendt før hovedkortet var ferdig med å bytte modus. Nå venter Kontrollsenter litt og sender "
            "fargene to ganger",
        ]),
    ]),
    ("0.22.0", "Del skjermbilder og klipp", [
        ("Nytt", [
            "Appen: Del-knapp på skjermbilder og klipp – også klipp fra de andre PC-ene. Bildet eller klippet hentes "
            "fra PC-en og åpnes i Androids delemeny (Messenger, Snapchat, Disk …). Krever den nye Android-appen",
        ]),
        ("Rettet", [
            "Statistikk på Spill-fanen var kuttet og rotete til du trykket «Vis all statistikk»",
            "«Måneden i tall» viser tekst til venstre og tall til høyre igjen",
        ]),
    ]),
    ("0.21.1", "Jevn dra-bevegelse på fanelinjen", [
        ("Rettet", [
            "Når du drar fingeren langs fanelinjen i appen, hopper ikke glasslinsen lenger tilbake til fanen du startet på",
        ]),
    ]),
    ("0.21.0", "Sveip mellom faner og lys som følger musa", [
        ("Nytt", [
            "Appen: dra fingeren bortover skjermen for å bytte fane – eller dra langs fanelinjen, så følger glasslinsen "
            "fingeren. Trykk virker som før",
            "Knappene i Kontrollsenter (Windows og Linux) lyser sterkest der musepekeren er, som knappene i Windows 11",
        ]),
    ]),
    ("0.20.5", "Verktøy i appen passer skjermen", [
        ("Rettet", [
            "Verktøy-fanen i appen kunne bli bredere enn skjermen mot Windows-PC-er, så fanelinjen ble for lang og "
            "siden kunne skrolles sidelengs. Innholdet klippes nå til skjermbredden",
            "Appen sier fra i feilloggen på PC-en hvis noe likevel blir for bredt, så det kan rettes",
        ]),
    ]),
    ("0.20.4", "Oppdater PC-en fra telefonen", [
        ("Nytt", [
            "Appen: Innstillinger → «Oppdater PC-en» henter siste versjon fra NAS-en og starter Kontrollsenter på nytt "
            "på PC-en – du slipper å gå bort til den",
        ]),
        ("Rettet", [
            "Fanelinjen nederst i appen holder seg alltid innenfor skjermen",
        ]),
    ]),
    ("0.20.3", "Windows-PC-ene og appen fungerer som de skal", [
        ("Rettet", [
            "Appen skalerte feil mot Windows-PC-er: lange Windows-stier og nettverksnavn gjorde siden bredere enn "
            "skjermen, så telefonen zoomet ut. Lange tekster brytes nå, og siden er aldri bredere enn skjermen",
            "Skjermbilder og klipp fra Windows-PC-er: Kontrollsenter finner nå Windows-mappen «Opptak» der den faktisk "
            "ligger (også i OneDrive), og skjermbilder tas med Windows' egen skjermkopi – uten Xbox Game Bar og PowerShell",
            "Skjermbilder får miniatyrbilde uten ffmpeg, og klipp uten miniatyrbilde vises med et pent ikon",
            "«Se på» og skjermbildet på Windows bruker riktige 64-bits typer mot Windows (kunne feile før)",
            "«Se på» på Linux husker tillatelsen til skjermdeling for Kontrollsenter",
            "RGB etter omstart: venter til OpenRGB er klar i stedet for å vise «Mistet kontakt»",
        ]),
    ]),
    ("0.20.2", "Enda lettere, og «Se på» på Linux", [
        ("Forbedret", [
            "Trege sensorer (RAM, NVMe og hovedkortbrikken) leses sjeldnere – CPU og GPU fortsatt hvert sekund – og "
            "vifteturtallet leses bare når du ser på det. Det fjerner små CPU-topper annethvert sekund",
            "Vinduet oppdateres annethvert sekund når det er åpent men ikke i fokus (f.eks. mens du spiller)",
            "Tyngre jobber (hjemmenett, prestasjoner, ønskeliste) spres utover etter oppstart i stedet for å kjøre samtidig",
        ]),
        ("Rettet", [
            "«Se på» på Linux kunne stoppe med «forhandlingsproblem» – bildet hentes nå på en måte som virker med "
            "skjermkortminne, og flere oppsett prøves automatisk",
        ]),
    ]),
    ("0.20.1", "Raskere og lettere", [
        ("Forbedret", [
            "Bruker langt mindre CPU: rundt 60 % mindre med vinduet åpent og rundt 90 % mindre når det ligger i "
            "bakgrunnen – vinduet oppdateres bare når det vises, mens varsler, viftekurve, historikk og mobilappen "
            "fortsatt får ferske tall",
            "Temperaturer, NVIDIA-data og prosessøk (spill, klipp, shadere) leses smartere og mellomlagres",
            "Appen: bakgrunnen står stille (mindre GPU-bruk), og «Batterisparing» – eller under 20 % batteri – slår av "
            "uskarpheten bak kortene",
        ]),
        ("Rettet", [
            "«Skjermen live» i appen er nå én knapp som åpner «Se på» (den gamle bilde-for-bilde-visningen er fjernet)",
            "Prestasjoner vises som merker i stedet for knapper som ikke gjorde noe",
            "Ubrukt kode er ryddet bort, og alle knapper er sjekket – på PC-en og i appen",
        ]),
    ]),
    ("0.20.0", "GPU-innstillinger for NVIDIA, AMD og Intel", [
        ("Nytt", [
            "Ny fane «GPU-innstillinger» som bare viser skjermkortene PC-en faktisk har – kraftigste først",
            "NVIDIA: live-tall (temperatur, last, strøm, klokker, VRAM, vifte, PCIe), strømgrense, låst GPU- og "
            "minneklokke og «persistence mode»",
            "AMD: ytelsesnivå, strømprofil og strømgrense (der kortet har det), og OverDrive – GPU- og minneklokke "
            "og spenningsavvik (undervolt), med «Tilbakestill» til fabrikk",
            "Intel: laveste, høyeste og boost-klokke",
            "Spillinnstillinger for Linux (DLSS i Proton, nyeste DLSS, stor shader-cache, raytracing på AMD, FSR, "
            "MangoHud) og Windows-grafikk (GPU-planlegging, spill i vindu, VRR)",
            "Valgfritt: bruk innstillingene dine igjen hver gang PC-en starter",
        ]),
    ]),
    ("0.19.0", "Widgets overalt og glød på knappene", [
        ("Nytt", [
            "Seks widgets: Kontrollsenter, Temperaturer, Hurtigknapper (spillmodus, klipp, lås, demp), Familien "
            "(hva de andre spiller + «Middag!»), Batterier og Spilletid i dag",
            "Android: hold fingeren på hjemskjermen → Widgets → Kontrollsenter",
            "Linux (KDE): Verktøy → Widgets → Installer, så «Legg til widgets» og søk «Kontrollsenter» – virker på "
            "skrivebordet og i panelet",
            "Windows (og Linux uten KDE): glass-widgets på skrivebordet fra Verktøy → Widgets – dra dem dit du vil, "
            "valgfritt «Alltid øverst»",
            "Tøff glød når musa er over knapper, brytere og valg – på eller av – på PC-en og i appen på nettbrett med mus",
        ]),
    ]),
    ("0.18.1", "Familie-fanen og «Se på» på Hjem", [
        ("Nytt", [
            "Ny fane «Familie» i sidemenyen: familiekontroll med kode øverst, «Se på» skjermen til de andre PC-ene "
            "(med forklaring hvis en PC trenger nyere versjon), og familie-chat, «Middag!», ekstra spilletid og leggetid",
            "I appen: «📺 Se på» først blant hurtigknappene på Hjem, og familiekontroll rett i Familie-kortet",
            "Kontrollsenter starter seg selv på nytt etter en oppdatering når vinduet er skjult og ingen spill kjører – "
            "så nye funksjoner faktisk blir tatt i bruk",
        ]),
    ]),
    ("0.18.0", "Flytende glass og familiekontroll med kode", [
        ("Nytt", [
            "Flytende glass på Linux, Windows og i mobilappen: glassaktige kort og knapper med lysrefleks i kanten, "
            "speilende skinn og farger som skinner gjennom. I appen glir en glasslinse mellom fanene. "
            "Kan slås av (Verktøy → Bakgrunn og varsler, og Innstillinger → Utseende i appen)",
            "Familiekontroll: velg en kode som trengs for å lukke Kontrollsenter. Lukkes vinduet, fortsetter "
            "programmet i bakgrunnen. Koden beskytter også familieinnstillingene, ekstra spilletid og bakgrunn/oppstart",
            "Slå familiekontroll av og på – og nullstill en glemt kode – fra telefonen (Spill → Familie)",
        ]),
    ]),
    ("0.17.1", "Elegante valglister og ryddige spillnavn", [
        ("Nytt", [
            "Alle nedtrekkslister i appen er byttet ut med en pen velger som glir opp nedenfra – med grupper, "
            "bilder, undertekst, hake på det valgte og søk i lange lister",
            "Statistikk: spillene er gruppert (World of Warcraft, Steam per konto) med Steam-bilde og timer spilt, "
            "og WoW-figurene vises som «Arthur – Level 1 · Human Warrior · Realm 8 PvP» med klasseikon",
            "Riktige spillnavn: «Counter-Strike 2» i stedet for «ValveTestApp260», «PUBG: Battlegrounds» osv.",
            "Tilbakeknappen på telefonen lukker velgeren, «Se på» og søket før den går til PC-lista",
        ]),
        ("Rettet", [
            "En feil i appen siden 0.15.0 stoppet mye av Verktøy- og Innstillinger-fanen (knappebord, hjemmenett, "
            "sikkerhetssjekk, Hue, RustDesk, søk og mer) – alt er tilbake",
            "Klipp-knappene står to og to, valgt hurtigtast vises tydelig, og lengdevalgene brytes ikke",
        ]),
    ]),
    ("0.17.0", "Ny drakt for mobilappen", [
        ("Nytt", [
            "Mobilappen har fått et helt nytt utseende: nattblå bakgrunn med nordlys, glasskort, flytende fanelinje "
            "og rolig, ryddig tekst – i mørkt og lyst tema",
            "PC-lista er bygget om: navn og status øverst, temperatur og strøm i egne bokser, og knappene "
            "(Åpne, Slå på) på en egen rad – de står aldri over teksten lenger",
            "Hurtigknappene på Hjem kan skyves sidelengs og viser hele teksten; målerne står i et jevnt rutenett",
            "Knapper på rad deler plassen likt, og lange statistikklister foldes sammen («Vis all statistikk»)",
        ]),
    ]),
    ("0.16.0", "Se på hva de andre spiller", [
        ("Nytt", [
            "«📺 Se på»: se skjermen til en annen PC i huset live – som casting fra Meta Quest. Bare visning, ingen kan "
            "styre PC-en, og den som blir sett på får beskjed",
            "Fra telefonen: Spill → Familie → «📺 Se på» ved PC-en (fullskjerm, snu telefonen for stort bilde). "
            "Telefonen trenger bare å være paret med én PC",
            "Fra PC-ene: «Se på»-knapp på kortene under PC-er hjemme (dobbeltklikk for fullskjerm)",
            "«Skjermen live» i appen viser nå jevn video i stedet for et bilde hvert par sekunder",
            "Kan slås av per PC: «La andre i huset se skjermen min» (Familie-kortet). Første gang på Linux spør "
            "PC-en om lov til å dele skjermen",
        ]),
    ]),
    ("0.15.0", "Strømming til telefonen, RustDesk og ryddigere skrift", [
        ("Nytt", [
            "Ny fane «Strømming»: spill og se PC-skjermen på telefonen med Sunshine og Moonlight – start/stopp, "
            "start med PC-en, hold i gang (starter igjen hvis den krasjer), paring med PIN og innstillinger",
            "I appen: «Spill på telefonen» åpner Moonlight direkte, og du kan pare telefonen uten å gå til PC-en",
            "RustDesk for fjernhjelp: ID-en vises på PC-en og i appen, og RustDesk kan åpnes og startes herfra",
            "Moonlight på PC-en: spill fra en annen PC i huset",
            "Hver side har en kort forklaring øverst, og kortene på Oversikt forklarer hva de gjør",
        ]),
        ("Rettet", [
            "Ryddigere skrift: mer luft mellom linjene, fast avstand mellom tittel og forklaring og like størrelser overalt",
            "Sunshine sto stoppet etter et krasj – Kontrollsenter starter den nå igjen av seg selv",
        ]),
    ]),
    ("0.14.0", "Nytt design", [
        ("Nytt", [
            "Helt nytt utseende på Linux og Windows: blå–lilla merkevare som i mobilappen, mykere kort med dybde, "
            "rolig lys bakgrunn og samme bredde på alle sider",
            "Sidemenyen er delt i Overvåking, Enheter, Spill og System, med logo, PC-navn og livestatus "
            "(CPU, GPU og watt) nederst",
            "Oversikt starter med en hilsen og en statusbrikke («Alt ser bra ut»), og toppfeltet viser PC-navn og oppetid",
            "Knapper, brytere, glidebrytere og valg følger det nye designet, i både lyst og mørkt tema",
        ]),
    ]),
    ("0.13.2", "RGB tilbake etter hvilemodus", [
        ("Rettet", [
            "RGB (bl.a. CPU-kjøleren på hovedkortets ARGB-uttak) ble mørk etter hvilemodus og etter omstart til du "
            "åpnet RGB-fanen. Nå legges de lagrede fargene inn av seg selv ved oppstart og hver gang PC-en våkner",
        ]),
    ]),
    ("0.13.1", "Batteri i mus og hodesett", [
        ("Nytt", [
            "Batteriprosent for alle trådløse enheter – mus, tastatur og hodesett – øverst på Oversikt, på "
            "Logitech-siden og på Hjem i appen",
            "Hodesett (Logitech G PRO X 2, G733, G535, G435, G933/G935 m.fl.) leses med HeadsetControl, som kan "
            "installeres med én knapp. Varsel om lavt batteri gjelder nå også hodesettet",
        ]),
    ]),
    ("0.13.0", "Familie, knappebord og mye mer", [
        ("Nytt", [
            "Familie: chat og «Middag!» til én eller alle PC-ene (vises over spillet med lyd), ekstra spilletid som "
            "belønning, leggetid som slår av PC-en, oversikt og ranking for alle PC-ene, og «Bli med» i samme spill",
            "Sikkerhetskopi og gjenoppretting av alle innstillinger på NAS-en, selvtest, feilrapport med ett trykk, "
            "og automatisk oppdatering om natten som rulles tilbake hvis den nye versjonen ikke starter",
            "Ytelse per spill (FPS, temperatur, strømkostnad), skjermkortdriver og varsel når Steam lager shadere",
            "Oppstartsprogrammer, enheter på hjemmenettet (varsel om nye), sikkerhetssjekk og Philips Hue-lys",
            "Tilbud på Steam-ønskelisten, prestasjoner og «Måneden i tall»",
            "Appen: knappebord (Stream Deck), søk, vis og skjul kort, dashbord for nettbrett, PC-skjermen live, "
            "batterisparing, offline-visning (meldinger sendes når PC-en svarer) og snarveien «Status»",
        ]),
    ]),
    ("0.12.1", "«Bare mens et spill kjører» virker", [
        ("Rettet", [
            "Klipp: «Bare mens et spill kjører» stoppet ikke opptaket, så F8 virket uten spill. Nå stopper opptaket "
            "når ingen spill kjører (60 s etter at spillet er avsluttet), og F8 sier fra",
            "Spill utenfor Steam gjenkjennes: World of Warcraft, Diablo, Warcraft III, Overwatch, Hearthstone m.fl.",
            "Flere opptak samtidig (fra en eldre utgave) ryddes bort automatisk",
        ]),
    ]),
    ("0.12.0", "Klipp: galleri, redigering og automatikk", [
        ("Nytt", [
            "Slett, favoritt (★) og miniatyrbilder for klipp – i Spill-fanen på PC-en og i appen",
            "CS2: klipp av seg selv ved 3K, 4K og ACE, kortet ned rundt killene, og hele kampen beholdes ved seier/MVP",
            "WoW: klipp av boss-kills og dødsfall fra kamploggen (skriv /combatlog i spillet)",
            "Flere hurtigtaster: bokmerke (10 s), siste 30 s, siste 5 min, start/stopp opptak og skjermbilde",
            "Kvalitet, bilder per sekund, oppløsning, mikrofon, egne lydspor (spill/Discord/mikrofon) og webkamera",
            "Redigering: klipp til, GIF, kort 720p, jevn lyd, vannmerke, skjul chat, HDR → SDR, montasje med musikk "
            "og «Beste fra uka»",
            "Rydding etter dager eller plass (favoritter beholdes), flytting og deling via NAS-en, delingslenke i 24 t",
            "Lyd og varsel når klipp lagres, pause når du er borte, kontroller (Select + Start), varsel om opptakshelse",
            "Appen: galleri med filter, avspilling med spilldata, last ned til telefonen, statistikk og «denne dagen»",
        ]),
    ]),
    ("0.11.1", "Velg hurtigtast for klipp", [
        ("Nytt", [
            "Velg hurtigtasten selv – en tast eller kombinasjon (F8, F9, Alt+F10, Ctrl+Shift+S …) – og «Test tasten»",
            "Hurtigtasten kan velges og testes fra appen på mobilen også",
        ]),
        ("Rettet", [
            "F8 virket ikke på KDE: hurtigtasten registreres nå direkte hos KDE (uten spørsmål), og virker i spill",
            "Opptaket i bakgrunnen kunne starte flere ganger samtidig",
        ]),
    ]),
    ("0.11.0", "Klipp – opptak i bakgrunnen", [
        ("Nytt", [
            "Klipp (som Medal/ShadowPlay): spillet tas opp i bakgrunnen, og F8 lagrer de siste sekundene som video",
            "Velg lengden selv (15 s – 5 min) og om opptaket bare skal gå mens et spill kjører",
            "Linux: GPU Screen Recorder (skjermkortets videokoder, med lyd) – installeres med én knapp. "
            "Windows: Xbox Game Bar sitt «Ta opp det som skjedde»",
            "Android: «Lagre klipp» på Hjem, hurtigflis i nedtrekksmenyen, og se eller slett klippene i appen",
        ]),
    ]),
    ("0.10.1", "Enkel visning kan slås av igjen", [
        ("Rettet", [
            "Appen: i enkel visning forsvant innstillingene, så den kunne ikke slås av. Innstillinger vises nå alltid, "
            "og Hjem har knappen «Avslutt enkel visning»",
        ]),
    ]),
    ("0.10.0", "Ny, enklere Android-app", [
        ("Nytt utseende", [
            "Appen er ryddet: fem faner – Hjem, Styr, Spill, Verktøy og Innstillinger – nederst på mobilen og som "
            "sidemeny på nettbrettet",
            "Hjem har hurtigknapper for spillmodus, strømmodus, andreskjerm og lås PC-en",
            "Roligere og mer elegant design med mørkt tema som standard; sjeldne valg er foldet sammen",
            "Ny startside med samme utseende",
        ]),
    ]),
    ("0.9.2", "Appen finner PC-ene også med VPN på", [
        ("Rettet", [
            "Android-appen fant ikke PC-ene når telefonen hadde VPN på (f.eks. Tailscale): den søkte i VPN-nettet. "
            "Nå brukes alltid Wi-Fi-nettet, og de vanlige hjemmenettene (192.168.1.x og 192.168.0.x) søkes også",
        ]),
    ]),
    ("0.9.1", "Appen finner Windows-PC-er", [
        ("Rettet", [
            "Windows: Android-appen fant ikke PC-en når Windows-brannmuren blokkerte Kontrollsenter (f.eks. etter at "
            "«Tillat»-spørsmålet ble lukket). Ny knapp «Rett brannmuren» i PC-er hjemme → Mobil og nettbrett, og "
            "installasjonsfilen retter det selv",
            "Feilsøkingsrapporten fra Windows viser fjernstyring, nettverksprofil og brannmurregler",
        ]),
    ]),
    ("0.9.0", "26 nye funksjoner i Android-appen", [
        ("Varsler og overvåking", [
            "Varsler på mobilen/nettbrettet fra PC-ene: varm CPU/GPU, vifte stoppet, full disk, spilletid nådd, "
            "ferdig spilløkt – også når appen er lukket (sjekkes hvert 15. minutt)",
            "Varsel hvis en PC slutter å svare uten å ha blitt slått av (strømbrudd eller krasj)",
            "Tidslinje over alt som har skjedd, og helsekort (A–F) med «Åpne Systemsjekk på PC-en»",
            "Widget på hjemmeskjermen og hurtigfliser for strømmodus og spillmodus",
        ]),
        ("Spill", [
            "Spillmodus med én knapp: max ytelse, viftekurve, RGB-farge, overlay på og varsler av – og tilbake",
            "Andreskjerm: store tall på nettbrettet mens du spiller (starter av seg selv, skjermen holdes våken)",
            "Spilletid per dag og uke, med grense og varsel (f.eks. for William)",
            "CS2 kamp for kamp: K/D og headshot over tid, og seier/K/D per kart",
            "WoW-mål: «level 20 innen søndag» med anslått spilletid",
            "Start spill på riktig PC: alle spillene fra alle PC-ene, med hvem som er ledig",
        ]),
        ("Fjernkontroll", [
            "Slå på PC-en fra appen (Wake-on-LAN) – også borte via en annen PC",
            "Alle PC-ene på én skjerm med temperatur, watt og spill",
            "Media (spill/pause/neste) og volum per program",
            "Send lenker og tekst til PC-en, også med «Del» fra andre apper, og hent PC-ens utklippstavle",
            "Skjermbilde av PC-en, og avslutt programmer som har hengt seg",
            "Slå av om 30 min / 1 t / 2 t eller når nedlastingene er ferdige",
            "Ping til ruter, NAS, Steam og Battle.net, og hvilke programmer som bruker nettet",
            "Strømkostnad i kroner per dag, uke og måned",
            "NAS-plass og sikkerhetskopi av lagrede spill",
        ]),
        ("Appen", [
            "Fingeravtrykk før «Slå av», «Start på nytt», vifter og «Avslutt»",
            "Begrenset tilgang per enhet (se alt og start spill, men ikke slå av eller endre innstillinger)",
            "Tema: auto, lyst, mørkt og AMOLED – og enkel visning med store fliser",
            "Engelsk språk i appen",
        ]),
    ]),
    ("0.8.5", "WoW-addonen bruker ikke kamploggen", [
        ("Rettet", [
            "WoW ba fortsatt om å slå av addonen: den lyttet på kamploggen, som er låst for addons i nyere WoW. "
            "Kills telles nå fra «… dies, you gain … experience», og «drept av» er fienden du hadde valgt",
            "Hvis WoW likevel blokkerer noe, lagrer addonen hva – og Spillstatistikk viser det",
        ]),
    ]),
    ("0.8.4", "WoW-addonen uten «disable/ignore»", [
        ("Rettet", [
            "WoW spurte om å slå av addonen etter /reload: den ba om /played, som er låst for addons i nyere "
            "WoW. Nå lytter den bare på spilletiden WoW sender selv, og regner videre mellom svarene",
        ]),
    ]),
    ("0.8.3", "WoW-addonen uten «blocked»-melding", [
        ("Rettet", [
            "WoW: «KontrollsenterStats has been blocked from an action only available to the Blizzard UI». Addonen "
            "byttet ut en Blizzard-funksjon for å skjule /played i chatten – nå dempes chatten bare et øyeblikk "
            "i stedet, og ingen Blizzard-funksjoner endres",
        ]),
    ]),
    ("0.8.2", "WoW-statistikk: hva mangler?", [
        ("Rettet", [
            "Spillstatistikk sier nå hvorfor WoW-tallene ikke vises ennå – f.eks. at WoW må startes helt på nytt "
            "etter at addonen ble lagt inn, eller at tallene kommer etter utlogging eller /reload",
        ]),
    ]),
    ("0.8.1", "App-oppdatering på Samsung", [
        ("Rettet", [
            "«Oppdater» i Android-appen feilet med «self update is blocked by unknown source package» på nyere "
            "Android/Samsung. Da åpnes nedlastingen i nettleseren i stedet – trykk på filen og velg Oppdater",
        ]),
    ]),
    ("0.8.0", "Spillstatistikk og appen utenfor hjemmenettet", [
        ("Spillstatistikk", [
            "CS2 live mens du spiller: stilling, kills, dødsfall, assists, headshots (%), skade, ADR, MVP, liv, "
            "penger og våpen – i Spill-fanen og øverst i appen",
            "CS2 totalt: K/D, headshot-prosent, treffsikkerhet, seiersrate, MVP, favorittvåpen, siste kamp og "
            "treff per våpen",
            "World of Warcraft per karakter (addonen «Kontrollsenter Stats» legges inn automatisk): spilletid totalt "
            "og per level, distanse (gått, ridd, svømt, flytaxi), kills og hva du dreper mest, dødsfall og hvem som "
            "drepte deg, quests, XP, gull, skade, største treff, healing, hopp, soner og siste økt. /ks viser dem i spillet",
            "Steam: spilletid, prestasjoner og all statistikk spillene lagrer – for hver Steam-konto på PC-en",
        ]),
        ("Android-appen", [
            "Virker utenfor hjemmenettet med Tailscale (privat og kryptert) – slå det på i PC-er hjemme → Mobil og "
            "nettbrett, og bruk samme konto i Tailscale-appen på mobilen/nettbrettet",
            "Samme paring hjemme og ute – appen velger adressen som svarer",
        ]),
    ]),
    ("0.7.2", "Oppdateringer i Android-appen", [
        ("Nytt", [
            "Android-appen sier fra når en ny versjon ligger på NAS-en – banner i appen, og varsel på telefonen/"
            "nettbrettet også når appen er lukket",
            "«Oppdater nå» laster ned og installerer den nye appen via PC-en (Android godtar bare en app med "
            "samme signatur)",
            "«Se etter oppdatering» på startsiden og i System-fanen",
        ]),
    ]),
    ("0.7.1", "Android-appen kobler til", [
        ("Rettet", [
            "Appen viste «error: finnes ikke» når du trykket «Åpne»: oppdateringen fra en eldre versjon tok ikke "
            "med kontrollpanelet. Nå kopieres hele pakken ved oppdatering, og filer som mangler hentes fra "
            "NAS-en ved oppstart",
            "Android-prosjektet kan åpnes og kjøres i Android Studio",
        ]),
    ]),
    ("0.7.0", "Android-app for mobil og nettbrett", [
        ("Nytt", [
            "Android-appen «Kontrollsenter» – styr PC-ene fra mobilen eller nettbrettet (laget også for store "
            "nettbrett som Galaxy Tab S11 Ultra)",
            "Oversikt med CPU, GPU, minne, temperaturer, strøm, disk og nett – oppdateres hvert 2. sekund",
            "Kontroll: strømmodus, vifter, lyd, RGB-lys, spill-overlay og MSI-innstillinger",
            "Historikk for siste time, døgn og uke, og start Steam-spill rett fra nettbrettet",
            "System: lås skjermen, hvilemodus, start på nytt og slå av",
            "Appen finner PC-ene på hjemmenettet selv. Slå på «Tillat fjernstyring» i PC-er hjemme og par "
            "med en 6-sifret kode",
        ]),
    ]),
    ("0.6.5", "Riktige temperaturer", [
        ("Rettet", [
            "Grenseverdier ble vist som temperaturer – f.eks. RAM-ens «Critical High Limit» (85 °C) ga rødt "
            "varsel, og «Distance to TjMax» så ut som CPU-temperatur. Nå vises bare ekte målinger",
            "Frakoblede sensorer på hovedkortet (0 °C, −62 °C) skjules",
        ]),
    ]),
    ("0.6.4", "Gjennomgang av Linux og Windows", [
        ("Rettet", [
            "Windows: utskrift fra Windows-verktøy (strømplan, Wi-Fi, ping, PowerShell) med æøå gikk tapt – "
            "tegnkoden leses nå riktig",
            "Historikken mistet målinger («database is locked») når to Kontrollsenter-prosesser kjørte samtidig",
            "Feilmeldinger uten tekst («Feil:») sier nå hva som skjedde",
            "Windows-installasjonen prøver OpenRGB på flere måter",
            "Linux-installasjonen spør ikke om passord når ingenting mangler",
        ]),
    ]),
    ("0.6.3", "OpenRGB på Windows", [
        ("Rettet", [
            "Installasjonsfilen fant ikke OpenRGB (pakken har fått nytt navn i winget) – nå installeres den",
        ]),
    ]),
    ("0.6.2", "Rolig installasjon på Windows", [
        ("Rettet", [
            "Installasjonsfilen viser ikke lenger et PowerShell-vindu – fremdriften vises i installasjonsvinduet",
            "MSI-styringen på Windows kjører helt uten vindu, også når den trenger administratorrett",
        ]),
    ]),
    ("0.6.1", "MSI-innstillinger på Windows", [
        ("Nytt", [
            "MSI på Windows: brukerscenario, Cooler Boost, viftemodus, Battery Master (ladegrense), Super Battery "
            "og webkamera styres nå direkte fra Kontrollsenter – uten MSI Center",
            "MSI-fanen viser CPU- og GPU-temperatur og viftefart rett fra MSI-kontrolleren",
        ]),
        ("Rettet", [
            "Windows nektet å starte Kontrollsenter-Setup.exe fra NAS-en («ingen tilgang») – filene får nå kjørerett",
        ]),
    ]),
    ("0.6.0", "Alle funksjonene på Windows", [
        ("Nytt på Windows", [
            "Vifter – styr viftene via LibreHardwareMonitor, med vifteprofiler og egne kurver",
            "RGB – OpenRGB finnes og startes automatisk, og installeres av installasjonsfilen",
            "Lyd – volum og demping for høyttalere og mikrofon, og volum per program",
            "Logitech – se Logitech-utstyret ditt og åpne eller installer G HUB",
            "MSI – maskin- og BIOS-info, batteri og snarvei til MSI Center",
            "Bluetooth og Wi-Fi – tilkoblede enheter, nettverk og signalstyrke",
            "Programmer – installer populære programmer og oppdater alle med winget, og velg hva som starter "
            "ved innlogging",
            "Spill – Steam-spillene dine med startvalg, og spillprofiler når et spill kjører",
            "Nettverk – ping, ruter og hvilke programmer som bruker nettet",
            "Verktøy – systeminfo til forum, «Rydd opp» (papirkurv, Temp, shader-cache), diskhelse, "
            "gjenopprettingspunkt og «Hva tar plass?»",
            "Systemsjekk – LibreHardwareMonitor, diskplass, programoppdateringer og Windows Update",
        ]),
    ]),
    ("0.5.3", "Windows: raskere og CPU-temperatur", [
        ("Rettet", [
            "Windows: vinduet hakket fordi det ventet på LibreHardwareMonitor og strømplanen hvert sekund – "
            "nå leses de i bakgrunnen",
            "LibreHardwareMonitor starter ved innlogging med ikon i statusfeltet, og Kontrollsenter starter den selv "
            "hvis den ikke svarer",
            "æøå i filer og rapporter på Windows",
        ]),
    ]),
    ("0.5.2", "Windows starter", [
        ("Rettet", [
            "Windows: programmet krasjet ved oppstart fordi Windows mangler lastsnitt (getloadavg) og statvfs",
            "Hvis noe likevel feiler ved oppstart, vises feilen i en melding og legges på NAS-en (Diagnose)",
        ]),
    ]),
    ("0.5.1", "Windows: NAS-adresse", [
        ("Rettet", [
            "Windows når NAS-en med navnet (\\\\PERSONALCLOUD) når IP-adressen avvises med «Brukernavnet eller "
            "passordet er feil» – gjelder installasjon, oppdateringer, PC-er hjemme og feilsøkingsrapport",
        ]),
    ]),
    ("0.5.0", "Kontrollsenter for Windows 11", [
        ("Windows 11 (første runde)", [
            "Installer fra NAS-en: åpne \\\\192.168.1.3\\Public\\Kontrollsenter\\Windows og dobbeltklikk "
            "«Installer Kontrollsenter»",
            "Oversikt med temperaturer, last, strøm og grafer (via LibreHardwareMonitor), historikk og PC-er hjemme",
            "Strømmodus bytter Windows-strømplan (Strømsparing, Balansert, Høy ytelse)",
            "Ikon i systemstatusfeltet, Windows-varsler og oppstart ved innlogging",
            "Oppdateringer fra NAS-en og feilsøkingsrapport – som på Linux",
            "Vifter, RGB, spill, nettverk, lyd, Bluetooth, Wi-Fi og programmer kommer i de neste rundene",
        ]),
    ]),
    ("0.4.2", "RGB og Logitech på flere PC-er", [
        ("Rettet", [
            "RGB virket ikke med OpenRGB 1.x: Effects-tillegget fikk tilkoblingen til å feile uten feilmelding",
            "Feilmeldinger i RGB-fanen sier nå hva som er galt i stedet for bare «Feil:»",
            "Logitech-fanen tilpasser seg enhetene som finnes, og viser en tydelig side når ingen har innstillinger",
        ]),
        ("Nytt", [
            "Corsair-hubber som OpenRGB ikke støtter (f.eks. iCUE COMMANDER DUO) – installer og åpne OpenLinkHub "
            "rett fra RGB-fanen",
            "Egne ikoner også i RGB-fanen",
        ]),
    ]),
    ("0.4.1", "Nytt ikon og feilsøking", [
        ("Nytt", [
            "Ny logo med lysende ring og pulslinje – på snarveien, i menyen og i Om-vinduet",
            "Eget ensfarget ikon i systemstatusfeltet som følger fargen på panelet",
            "Ikonene installeres automatisk",
            "Feilsøkingsrapport (Verktøy): maskinvare, drivere, OpenRGB, ratbagd og Solaar – legges på NAS-en "
            "så feil på andre PC-er kan finnes",
        ]),
        ("Rettet", [
            "Viftestyring på ASUS-hovedkort med Intel (f.eks. PRIME Z270): viftebrikken er sperret av BIOS – "
            "«Rett viftebrikken» legger inn oppstartsvalget som løser det",
        ]),
    ]),
    ("0.4", "Mer automatikk, mer oversikt", [
        ("Spill", [
            "Automatiske spillprofiler: strømmodus, vifter og RGB byttes når et Steam-spill starter – og tilbake "
            "når det avsluttes. Egne innstillinger per spill",
            "Rapport etter hver spilløkt: spilletid, snitt-FPS, «1 % low», høyeste temperaturer og strømkostnad",
            "Sikkerhetskopi av lagrede spill til NAS-en – også spill som ikke ligger i Steam Cloud – og henting tilbake",
        ]),
        ("Vifter og strøm", [
            "Viftekurver: dra punkter på en graf, så følger viftene temperaturen",
            "Stille om natten: rolig PC i tidsrommet du velger, med stille vifter, Strømsparing og RGB av",
            "Strømforbruk med pris: målt watt for CPU og skjermkort, kWh og kroner i dag, og anslag per måned",
        ]),
        ("Oversikt og system", [
            "Historikk: temperaturer, last og strøm for siste time, døgn eller uke",
            "Hva tar plass? De største mappene og spillene, med Åpne og Avinstaller",
            "Nettverk: ping til ruter, NAS og spilltjenere, hastighetstest og programmer som bruker nettet",
            "PC-er hjemme: se temperatur, strøm, spill og versjon på alle PC-ene på hjemmenettet",
        ]),
        ("Utseende", [
            "Eget programikon",
            "Nøkkeltall øverst i Oversikt med runde temperaturmål i grønt, gult og rødt",
            "Grafer: velg 1 min, 10 min eller 1 time, og hold musa over for verdi og tidspunkt",
            "Mini-vindu som ligger øverst med temperaturer og strøm (Meny → Mini-vindu)",
            "Levende sidemeny: temperatur ved Oversikt, ▶ ved Spill når et spill kjører, antall Bluetooth-enheter",
            "Velkomstveiviser første gang (og i Meny → Velkomstveiviser)",
        ]),
    ]),
    ("0.3.1", "Riktig versjon etter oppdatering", [
        ("Rettet", [
            "«Se etter oppdatering» sammenligner nå med versjonen som faktisk kjører – ikke bare filene på disken",
            "Kjører Kontrollsenter i bakgrunnen når en ny versjon installeres, kommer et varsel og et banner "
            "med «Start på nytt»",
            "«Start på nytt»-knapp i Verktøy etter oppdatering",
        ]),
    ]),
    ("0.3", "Enkelt og elegant", [
        ("Nytt utseende", [
            "Sidemeny til venstre i stedet for fanerad – roligere, og plass til flere sider",
            "Meny (☰) med Systemsjekk, Hva er nytt?, Språk og Om Kontrollsenter",
            "Om-vindu med versjon, copyright og nyheter – copyright-linjen øverst er borte",
            "Spill-overlay er et lite ikon øverst til høyre som lyser når det er på",
            "Egne, enhetlige ikoner som passer i både lyst og mørkt tema",
        ]),
        ("Ryddigere", [
            "Vifter som står stille (0 RPM) skjules – «Vis vifter som står stille» viser dem",
            "Tilbakestill er flyttet nederst og gjort diskret",
            "Korte meldinger («Lagret ✓», «Kopiert ✓») glir opp nederst og forsvinner av seg selv",
            "Pene tomme sider når noe mangler, f.eks. ingen kontroller eller Bluetooth-enheter",
            "CPU-grafen følger systemets aksentfarge",
            "Innholdet strekkes ikke ut på brede skjermer, men holdes samlet i midten",
            "Smalt vindu: sidemenyen legger seg bort, og du blar mellom meny og side",
        ]),
    ]),
    ("0.2", "Bare det du har", [
        ("Tilpasset maskinen din", [
            "RGB, Logitech, CPU-skjerm, Wi-Fi og Bluetooth vises bare når utstyret finnes i maskinen",
            "Installasjonen legger bare inn OpenRGB, Solaar, ratbagd, TRCC og tilhørende regler når utstyret finnes",
            "Systemsjekk, Programmer og Oppstart hopper over RGB-, Logitech- og CPU-skjerm-programmer du ikke trenger",
        ]),
        ("Oppdateringer på hjemmenettet", [
            "Ser etter nye versjoner på NAS-en (\\\\192.168.1.3\\Public\\Kontrollsenter) når PC-en er på hjemmenettet",
            "Varsler om ny versjon, og oppdaterer med ett klikk – pakken sjekksum-kontrolleres og forrige versjon tas vare på",
            "Nye versjoner legges ut på NAS-en automatisk",
        ]),
    ]),
    ("0.1", "Første versjon", [
        ("Nytt navn og språk", [
            "Programmet heter nå Kontrollsenter (Control Center på engelsk)",
            "Språket følger Linux automatisk (Auto) – du kan fortsatt velge NO eller EN selv",
        ]),
        ("Nye faner", [
            "Bluetooth – søk, par og koble til hodetelefoner, kontrollere og høyttalere, og se batteriet deres",
            "Spill – startvalg per Steam-spill med avkrysning: MangoHud, GameMode, Wayland, DLSS, FSR, HDR og "
            "Proton-logg, pluss Proton-versjon per spill og egne argumenter",
            "Spill – installer nyeste GE-Proton med ett klikk (sjekksum-kontrollert), og slett gamle versjoner",
            "Spill – kontrollere med batteri og knappetest",
            "Verktøy – systeminfo med «Kopier til forum», perfekt når du ber om hjelp",
            "Verktøy – «Rydd opp»: papirkurv, Steam shader-cache, Proton-prefikser, Flatpak-rester, gamle logger "
            "og pakkecache, med størrelse på alt før noe slettes",
            "Verktøy – diskhelse (SMART): slitasje, reservekapasitet, feil og temperatur – uten passord",
            "Verktøy – gjenoppretting: gå tilbake til forrige systemversjon (Bazzite) eller ta øyeblikksbilder "
            "(snapper/Timeshift)",
            "Verktøy – sikkerhetskopi av alle Kontrollsenter-innstillinger til én fil, og import på en ny PC",
            "Verktøy – oppdater Kontrollsenter fra Git, og lag installasjonspakke med ett klikk",
        ]),
        ("Bakgrunn og varsler", [
            "Ikon i systemstatusfeltet med temperaturer, strømmodus, overlay og avslutt",
            "Kan kjøre i bakgrunnen når vinduet lukkes – overlay, vifter og varsler fortsetter",
            "Varsler ved høy temperatur, nesten full disk, lavt batteri i mus/hodesett/kontroller, "
            "feil i Systemsjekk og tilgjengelige oppdateringer",
            "Kan starte skjult ved innlogging (Programmer → Oppstart)",
        ]),
        ("Tryggere og raskere", [
            "Øyeblikksbilde tas automatisk før systemoppdateringer (snapper/Timeshift der det finnes)",
            "NVIDIA-data leses direkte (NVML) – over 10 ganger raskere, uten nytt program hvert sekund",
            "Feillogg i ~/.cache/systemmonitor/logg.txt – vises og kopieres fra Verktøy",
            "Koden er delt opp og lagt under versjonskontroll (Git), så endringer kan angres",
            "Fanene kan rulles sidelengs i smale vinduer",
            "Versjonsnummer under copyright, og denne «Hva er nytt?»-knappen",
        ]),
        ("Alt fra før", [
            "Oversikt: CPU, RAM, GPU, disk, nett, temperaturer, strømmodus, viftestyring, spill-overlay og batteri",
            "RGB, Logitech (som G HUB), CPU-skjerm (Thermalright), Programmer med oppstart, Lyd, Wi-Fi og MSI",
            "Systemsjekk med automatisk retting av pakke-, oppdaterings-, driver- og Wi-Fi-feil på alle distroer",
            "Norsk og engelsk, og installasjonspakke for andre PC-er",
        ]),
    ]),
]

# Eldre og nyere oppføringer: (versjon, tittel, [(avsnitt, [punkter])]) – noen har punktene rett under versjonen.
# Gjør alle like, så «Hva er nytt?», «Om» og GitHub-utgivelsene alltid kan lese dem.
NEWS = [(v, t, g if (g and isinstance(g[0], (tuple, list))) else [("Nytt", list(g))]) for v, t, g in NEWS]


def current_version():
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "VERSION")) as f:
            return f.read().strip()
    except OSError:
        return "?"


def should_show():
    try:
        with open(SEEN) as f:
            return json.load(f).get("version") != current_version()
    except (OSError, ValueError):
        return True


def mark_seen():
    try:
        os.makedirs(os.path.dirname(SEEN), exist_ok=True)
        with open(SEEN, "w") as f:
            json.dump({"version": current_version()}, f)
    except OSError:
        pass


def last_seen():
    try:
        with open(SEEN) as f:
            return json.load(f).get("version")
    except (OSError, ValueError):
        return None


def _vt(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


# Illustrasjon og «Vis meg»-side ut fra hva punktet handler om (første treff vinner)
ART = [
    (r"skjermkort|GPU|FPS|HDR|oppløsning|Hz\b", "🖥️", "gpu"), (r"lyd|mikrofon|hodesett|høyttaler", "🎧", "lyd"),
    (r"nattlys|lysstyrke", "🌙", "gpu"), (r"klipp|Medal|opptak|Game Bar", "🎬", "spill"),
    (r"spill|Steam|launcher|Heroic|Lutris", "🎮", "spill"), (r"Discord", "💬", "discord"),
    (r"Familie|leksetid|nettfilter|ukeplan|stjern|belønning|spilletid|leggetid", "👨‍👩‍👧", "familie"),
    (r"Scene", "✨", "scener"), (r"Smart Hjem|Hue|Chromecast|radio|hjemme/borte|strømpris", "🏠", "smarthjem"),
    (r"Strømming|Sunshine|Moonlight|RustDesk|«Se på»", "📡", "stromming"),
    (r"mobil|Android|widget|telefon|ntfy|push", "📱", None), (r"NAS|sikkerhetskopi|oppdatering|selvtest|versjon", "🛡️", "innstillinger"),
    (r"Innstillinger|søk|enkel modus", "⚙️", "innstillinger"), (r"Vedlikehold|oppstart|ytelsestest|vifte", "🔧", "verktoy"),
]


def _art(text):
    import re as _re
    for rx, emoji, page in ART:
        if _re.search(rx, text, _re.I):
            return emoji, page
    return "✨", None


CSS = """
.ks-news-hero { border-radius: 22px; padding: 18px 20px; background-image: linear-gradient(135deg, alpha(@accent_bg_color, .55), alpha(@accent_bg_color, .12)); }
.ks-news-card { border-radius: 18px; padding: 14px; }
.ks-news-art { font-size: 34px; min-width: 56px; min-height: 56px; border-radius: 16px; background: alpha(currentColor, .07); }
.ks-news-ver { font-weight: 800; }
"""


class WhatsNewDialog(Adw.Dialog):
    """«Hva er nytt?» – det nye siden sist øverst som kort med illustrasjon og «Vis meg», eldre versjoner
    sammenfoldet og søkbare."""

    def __init__(self):
        super().__init__(title=i18n.tr("Hva er nytt?"), content_width=760, content_height=760)
        try:
            import theme
            theme.add_css(CSS, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 4)
        except Exception:  # noqa: BLE001
            pass
        seen = last_seen()
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        for side in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{side}")(20)
        new = [n for n in NEWS if seen is None or _vt(n[0]) > _vt(seen)] or NEWS[:1]
        old = [n for n in NEWS if n not in new]
        hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        hero.add_css_class("ks-news-hero")
        ht = Gtk.Label(label=i18n.tr("Nytt siden sist") if seen and len(new) > 1 else
                       f"{i18n.tr('Versjon')} {new[0][0]} – {i18n.tr(new[0][1])}", xalign=0, wrap=True)
        ht.add_css_class("title-1")
        hero.append(ht)
        n_items = sum(len(items) for _v, _t, secs in new for _s, items in secs)
        hs = Gtk.Label(label=(f"{len(new)} " + i18n.tr("versjoner") + " · " if len(new) > 1 else "") +
                       f"{n_items} " + i18n.tr("nyheter og forbedringer"), xalign=0)
        hs.add_css_class("dim-label")
        hero.append(hs)
        box.append(hero)
        for ver, title, sections in new:
            if len(new) > 1:
                h = Gtk.Label(label=f"{ver} – {i18n.tr(title)}", xalign=0, margin_top=6)
                h.add_css_class("ks-news-ver")
                h.add_css_class("title-4")
                box.append(h)
            flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=2,
                               min_children_per_line=1, column_spacing=10, row_spacing=10, homogeneous=True)
            for sec, items in sections:
                for it in items:
                    flow.append(self._card(it, sec))
            box.append(flow)
        if old:
            oh = Gtk.Label(label=i18n.tr("Tidligere versjoner"), xalign=0, margin_top=12)
            oh.add_css_class("title-4")
            box.append(oh)
            self.find = Gtk.SearchEntry(placeholder_text=i18n.tr("Søk i alt som er nytt, f.eks. «Discord»"))
            box.append(self.find)
            self.old_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            box.append(self.old_box)
            self.old = old
            self.find.connect("search-changed", lambda *_: self._fill_old())
            self._fill_old()
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.set_child(box)
        tv.set_content(sc)
        self.set_child(tv)
        mark_seen()

    def _card(self, text, sec):
        emoji, page = _art(text)
        c = Gtk.Box(spacing=12)
        c.add_css_class("card")
        c.add_css_class("ks-news-card")
        art = Gtk.Label(label=emoji, valign=Gtk.Align.START)
        art.add_css_class("ks-news-art")
        c.append(art)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, hexpand=True)
        tag = Gtk.Label(label=i18n.tr(sec).upper(), xalign=0)
        tag.add_css_class("caption-heading")
        tag.add_css_class("dim-label")
        col.append(tag)
        col.append(Gtk.Label(label=i18n.tr(text), xalign=0, wrap=True))
        if page:
            b = Gtk.Button(label=i18n.tr("Vis meg"), halign=Gtk.Align.START)
            b.add_css_class("pill")
            b.add_css_class("suggested-action")
            b.connect("clicked", lambda *_: self._show(page))
            col.append(b)
        c.append(col)
        return c

    def _show(self, page):
        win = self.get_root()
        app_win = win.get_transient_for() if hasattr(win, "get_transient_for") else None
        self.close()
        for w in (app_win, win, Gtk.Application.get_default() and Gtk.Application.get_default().get_active_window()):
            if w is not None and hasattr(w, "stack"):
                w.stack.set_visible_child_name(page)
                break

    def _fill_old(self):
        while (ch := self.old_box.get_first_child()) is not None:
            self.old_box.remove(ch)
        q = self.find.get_text().strip().lower()
        shown = 0
        for ver, title, sections in self.old:
            items = [(sec, it) for sec, its in sections for it in its if not q or q in (it + title).lower()]
            if not items:
                continue
            exp = Gtk.Expander(label=f"{ver} – {i18n.tr(title)}", expanded=bool(q) and shown < 6)
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin_start=18, margin_top=4)
            for sec, it in items:
                row = Gtk.Box(spacing=8)
                row.append(Gtk.Label(label=_art(it)[0], yalign=0))
                row.append(Gtk.Label(label=i18n.tr(it), xalign=0, wrap=True, hexpand=True))
                inner.append(row)
            exp.set_child(inner)
            self.old_box.append(exp)
            shown += 1
            if shown >= 60:
                break
